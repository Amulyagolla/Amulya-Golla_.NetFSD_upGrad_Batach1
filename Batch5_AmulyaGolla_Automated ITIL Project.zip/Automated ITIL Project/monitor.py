# filepath: monitor.py
"""
System Monitoring Module for IT Service Desk
Monitors CPU, Memory, Disk, and Network usage
"""

import psutil
import time
from datetime import datetime
from typing import Dict, List, Optional
from utils import DateTimeHelper, IDGenerator
from logger import logger, WARNING, CRITICAL
from tickets import TicketManager


class Monitor:
    """System Monitor class for tracking system resources"""
    
    # Threshold constants
    CPU_THRESHOLD = 90.0
    MEMORY_THRESHOLD = 95.0
    DISK_THRESHOLD = 10.0  # Free space percentage
    
    def __init__(self):
        """Initialize the monitor"""
        self._alert_history: List[Dict] = []
        self._last_check = None
    
    @property
    def alert_history(self) -> List[Dict]:
        """Get alert history"""
        return self._alert_history
    
    @property
    def last_check(self) -> str:
        """Get last check time"""
        return self._last_check
    
    # Static methods
    @staticmethod
    def get_cpu_usage() -> float:
        """Get current CPU usage percentage"""
        return psutil.cpu_percent(interval=1)
    
    @staticmethod
    def get_memory_usage() -> Dict:
        """Get memory usage details"""
        memory = psutil.virtual_memory()
        return {
            'total': memory.total,
            'available': memory.available,
            'used': memory.used,
            'percent': memory.percent,
            'total_gb': round(memory.total / (1024**3), 2),
            'available_gb': round(memory.available / (1024**3), 2),
            'used_gb': round(memory.used / (1024**3), 2)
        }
    
    @staticmethod
    def get_disk_usage() -> Dict:
        """Get disk usage details"""
        disk = psutil.disk_usage('C:\\' if __import__('os').name == 'nt' else '/')
        return {
            'total': disk.total,
            'used': disk.used,
            'free': disk.free,
            'percent': disk.percent,
            'total_gb': round(disk.total / (1024**3), 2),
            'free_gb': round(disk.free / (1024**3), 2)
        }
    
    @staticmethod
    def get_network_usage() -> Dict:
        """Get network usage details"""
        net = psutil.net_io_counters()
        return {
            'bytes_sent': net.bytes_sent,
            'bytes_recv': net.bytes_recv,
            'packets_sent': net.packets_sent,
            'packets_recv': net.packets_recv,
            'mb_sent': round(net.bytes_sent / (1024**2), 2),
            'mb_recv': round(net.bytes_recv / (1024**2), 2)
        }
    
    @staticmethod
    def get_system_info() -> Dict:
        """Get comprehensive system information"""
        return {
            'cpu': {
                'usage_percent': Monitor.get_cpu_usage(),
                'count': psutil.cpu_count(),
                'count_logical': psutil.cpu_count(logical=True)
            },
            'memory': Monitor.get_memory_usage(),
            'disk': Monitor.get_disk_usage(),
            'network': Monitor.get_network_usage()
        }
    
    def check_all(self) -> Dict:
        """Check all system resources and return status"""
        self._last_check = DateTimeHelper.get_current_datetime()
        
        cpu = self.get_cpu_usage()
        memory = self.get_memory_usage()
        disk = self.get_disk_usage()
        
        status = {
            'timestamp': self._last_check,
            'cpu': {
                'value': cpu,
                'threshold': self.CPU_THRESHOLD,
                'alert': cpu > self.CPU_THRESHOLD
            },
            'memory': {
                'value': memory['percent'],
                'threshold': self.MEMORY_THRESHOLD,
                'alert': memory['percent'] > self.MEMORY_THRESHOLD
            },
            'disk': {
                'value': 100 - disk['percent'],  # Free space
                'threshold': self.DISK_THRESHOLD,
                'alert': (100 - disk['percent']) < self.DISK_THRESHOLD
            }
        }
        
        # Check for alerts
        alerts = []
        if status['cpu']['alert']:
            alerts.append(f"CPU usage ({cpu}%) exceeds threshold ({self.CPU_THRESHOLD}%)")
            logger.log_monitoring_alert('CPU', cpu, self.CPU_THRESHOLD)
        
        if status['memory']['alert']:
            alerts.append(f"Memory usage ({memory['percent']}%) exceeds threshold ({self.MEMORY_THRESHOLD}%)")
            logger.log_monitoring_alert('Memory', memory['percent'], self.MEMORY_THRESHOLD)
        
        if status['disk']['alert']:
            alerts.append(f"Disk free space ({100 - disk['percent']}%) below threshold ({self.DISK_THRESHOLD}%)")
            logger.log_monitoring_alert('Disk', 100 - disk['percent'], self.DISK_THRESHOLD)
        
        status['alerts'] = alerts
        status['has_alerts'] = len(alerts) > 0
        
        # Store in history
        self._alert_history.append(status)
        
        return status
    
    def check_cpu(self) -> bool:
        """Check if CPU usage exceeds threshold"""
        cpu = self.get_cpu_usage()
        if cpu > self.CPU_THRESHOLD:
            logger.log_monitoring_alert('CPU', cpu, self.CPU_THRESHOLD)
            return True
        return False
    
    def check_memory(self) -> bool:
        """Check if memory usage exceeds threshold"""
        memory = self.get_memory_usage()
        if memory['percent'] > self.MEMORY_THRESHOLD:
            logger.log_monitoring_alert('Memory', memory['percent'], self.MEMORY_THRESHOLD)
            return True
        return False
    
    def check_disk(self) -> bool:
        """Check if disk free space is below threshold"""
        disk = self.get_disk_usage()
        free_percent = 100 - disk['percent']
        if free_percent < self.DISK_THRESHOLD:
            logger.log_monitoring_alert('Disk', free_percent, self.DISK_THRESHOLD)
            return True
        return False
    
    def get_alert_summary(self) -> Dict:
        """Get summary of all alerts"""
        return {
            'total_alerts': len(self._alert_history),
            'cpu_alerts': sum(1 for a in self._alert_history if a.get('cpu', {}).get('alert')),
            'memory_alerts': sum(1 for a in self._alert_history if a.get('memory', {}).get('alert')),
            'disk_alerts': sum(1 for a in self._alert_history if a.get('disk', {}).get('alert')),
            'last_check': self._last_check
        }
    
    def clear_history(self):
        """Clear alert history"""
        self._alert_history.clear()
        logger.info("Alert history cleared")


class AutoTicketCreator:
    """Automatically creates tickets based on monitoring alerts"""
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize auto ticket creator"""
        self._ticket_manager = ticket_manager or TicketManager()
        self._monitor = Monitor()
    
    @property
    def ticket_manager(self) -> TicketManager:
        """Get ticket manager"""
        return self._ticket_manager
    
    @property
    def monitor(self) -> Monitor:
        """Get monitor"""
        return self._monitor
    
    def check_and_create_ticket(self) -> Optional[str]:
        """Check system and create ticket if thresholds exceeded"""
        status = self._monitor.check_all()
        
        if not status['has_alerts']:
            return None
        
        # Determine the highest priority issue
        ticket_id = None
        
        if status['cpu']['alert']:
            ticket_id = self._create_system_ticket(
                issue_type='High CPU Usage',
                description=f"CPU usage at {status['cpu']['value']}% (threshold: {status['cpu']['threshold']}%)",
                priority='P1'
            )
        
        if status['memory']['alert']:
            ticket_id = self._create_system_ticket(
                issue_type='High Memory Usage',
                description=f"Memory usage at {status['memory']['value']}% (threshold: {status['memory']['threshold']}%)",
                priority='P1'
            )
        
        if status['disk']['alert']:
            ticket_id = self._create_system_ticket(
                issue_type='Disk Space Low',
                description=f"Free disk space at {status['disk']['value']}% (threshold: {status['disk']['threshold']}%)",
                priority='P1'
            )
        
        return ticket_id
    
    def _create_system_ticket(self, issue_type: str, description: str, 
                              priority: str = 'P1') -> str:
        """Create a system-generated ticket"""
        ticket = self._ticket_manager.create_ticket(
            employee_name='System Monitor',
            department='IT Operations',
            issue_description=description,
            category=issue_type,
            ticket_type='Incident',
            priority=priority,
            incident_type=issue_type,
            impact_level='High',
            urgency='High'
        )
        
        logger.info(f"Auto-created ticket for {issue_type}: {ticket.ticket_id}")
        return ticket.ticket_id
    
    def start_monitoring_loop(self, interval: int = 60, duration: int = None):
        """Start continuous monitoring loop"""
        import threading
        
        def monitor_loop():
            start_time = time.time()
            
            while True:
                self.check_and_create_ticket()
                
                if duration:
                    elapsed = time.time() - start_time
                    if elapsed >= duration:
                        break
                
                time.sleep(interval)
        
        thread = threading.Thread(target=monitor_loop, daemon=True)
        thread.start()
        return thread


class MonitoringService:
    """Service class for managing monitoring operations"""
    
    def __init__(self):
        """Initialize monitoring service"""
        self._monitor = Monitor()
        self._auto_creator = None
        self._is_running = False
    
    @property
    def monitor(self) -> Monitor:
        """Get monitor"""
        return self._monitor
    
    @property
    def auto_creator(self) -> AutoTicketCreator:
        """Get auto ticket creator"""
        return self._auto_creator
    
    def enable_auto_ticket(self, ticket_manager: TicketManager):
        """Enable automatic ticket creation"""
        self._auto_creator = AutoTicketCreator(ticket_manager)
        logger.info("Auto ticket creation enabled")
    
    def disable_auto_ticket(self):
        """Disable automatic ticket creation"""
        self._auto_creator = None
        logger.info("Auto ticket creation disabled")
    
    def get_system_status(self) -> Dict:
        """Get current system status"""
        return self._monitor.check_all()
    
    def get_system_health(self) -> str:
        """Get system health status"""
        status = self._monitor.check_all()
        
        if status['has_alerts']:
            return "CRITICAL" if len(status['alerts']) >= 2 else "WARNING"
        
        return "HEALTHY"
    
    def generate_health_report(self) -> str:
        """Generate a health report"""
        status = self._monitor.check_all()
        health = self.get_system_health()
        
        report = f"""
=== System Health Report ===
Generated: {status['timestamp']}
Health Status: {health}

CPU Usage: {status['cpu']['value']}% (Threshold: {status['cpu']['threshold']}%)
Memory Usage: {status['memory']['value']}% (Threshold: {status['memory']['threshold']}%)
Disk Free: {status['disk']['value']}% (Threshold: {status['disk']['threshold']}%)
"""
        
        if status['alerts']:
            report += "\nAlerts:\n"
            for alert in status['alerts']:
                report += f"  - {alert}\n"
        
        return report


# Standalone function for quick checks
def quick_system_check() -> Dict:
    """Quick system check - returns basic status"""
    monitor = Monitor()
    return monitor.check_all()


def get_system_metrics() -> Dict:
    """Get all system metrics"""
    return Monitor.get_system_info()


# Generator for continuous monitoring
def continuous_monitor(interval: int = 60):
    """Generator for continuous monitoring"""
    monitor = Monitor()
    
    while True:
        status = monitor.check_all()
        yield status
        time.sleep(interval)


# Iterator class for monitoring
class MonitoringIterator:
    """Iterator for continuous monitoring"""
    
    def __init__(self, interval: int = 60):
        self._interval = interval
        self._monitor = Monitor()
        self._running = False
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if not self._running:
            self._running = True
            raise StopIteration
        
        status = self._monitor.check_all()
        time.sleep(self._interval)
        return status
    
    def start(self):
        """Start the iterator"""
        self._running = True
    
    def stop(self):
        """Stop the iterator"""
        self._running = False