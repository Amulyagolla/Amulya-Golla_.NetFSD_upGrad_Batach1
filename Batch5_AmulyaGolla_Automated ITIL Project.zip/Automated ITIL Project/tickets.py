# filepath: tickets.py
"""
Ticket Management Module for IT Service Desk
Contains all ticket-related classes and operations
"""

from datetime import datetime
from typing import List, Dict, Optional
from utils import (
    FileHandler, Validator, DataProcessor, DateTimeHelper, 
    IDGenerator, get_open_tickets, get_high_priority_tickets
)
from logger import logger, INFO, WARNING, ERROR
import json


class Ticket:
    """Base Ticket class with core attributes and methods"""
    
    # Class variables
    PRIORITY_LEVELS = ['P1', 'P2', 'P3', 'P4']
    STATUS_OPTIONS = ['Open', 'In Progress', 'Pending', 'Resolved', 'Closed']
    
    # Special methods
    def __init__(self, ticket_id: str, employee_name: str, department: str,
                 issue_description: str, category: str, priority: str, status: str,
                 created_date: str = None):
        """Constructor - Initialize ticket with all attributes"""
        self._ticket_id = ticket_id
        self._employee_name = employee_name
        self._department = department
        self._issue_description = issue_description
        self._category = category
        self._priority = priority
        self._status = status
        self._created_date = created_date or DateTimeHelper.get_current_datetime()
        self._updated_date = self._created_date
        self._resolved_date = None
        self._closed_date = None
        self._resolution = None
        self._assigned_to = None
        self._notes = []
    
    # Encapsulation - Property decorators
    @property
    def ticket_id(self) -> str:
        """Get ticket ID"""
        return self._ticket_id
    
    @property
    def employee_name(self) -> str:
        """Get employee name"""
        return self._employee_name
    
    @employee_name.setter
    def employee_name(self, value: str):
        """Set employee name with validation"""
        Validator.validate_non_empty(value, "Employee name")
        self._employee_name = value
    
    @property
    def department(self) -> str:
        """Get department"""
        return self._department
    
    @department.setter
    def department(self, value: str):
        """Set department with validation"""
        Validator.validate_non_empty(value, "Department")
        self._department = value
    
    @property
    def issue_description(self) -> str:
        """Get issue description"""
        return self._issue_description
    
    @issue_description.setter
    def issue_description(self, value: str):
        """Set issue description"""
        self._issue_description = value
    
    @property
    def category(self) -> str:
        """Get category"""
        return self._category
    
    @category.setter
    def category(self, value: str):
        """Set category"""
        self._category = value
    
    @property
    def priority(self) -> str:
        """Get priority"""
        return self._priority
    
    @priority.setter
    def priority(self, value: str):
        """Set priority with validation"""
        if value not in self.PRIORITY_LEVELS:
            raise ValueError(f"Invalid priority. Must be one of {self.PRIORITY_LEVELS}")
        self._priority = value
    
    @property
    def status(self) -> str:
        """Get status"""
        return self._status
    
    @status.setter
    def status(self, value: str):
        """Set status with validation"""
        if value not in self.STATUS_OPTIONS:
            raise ValueError(f"Invalid status. Must be one of {self.STATUS_OPTIONS}")
        old_status = self._status
        self._status = value
        self._updated_date = DateTimeHelper.get_current_datetime()
        
        # Update resolved/closed dates
        if value == 'Resolved' and not self._resolved_date:
            self._resolved_date = self._updated_date
        elif value == 'Closed' and not self._closed_date:
            self._closed_date = self._updated_date
        
        logger.log_ticket_updated(self._ticket_id, old_status, value)
    
    @property
    def created_date(self) -> str:
        """Get created date"""
        return self._created_date
    
    @property
    def updated_date(self) -> str:
        """Get updated date"""
        return self._updated_date
    
    @property
    def resolved_date(self) -> str:
        """Get resolved date"""
        return self._resolved_date
    
    @property
    def closed_date(self) -> str:
        """Get closed date"""
        return self._closed_date
    
    @property
    def resolution(self) -> str:
        """Get resolution"""
        return self._resolution
    
    @resolution.setter
    def resolution(self, value: str):
        """Set resolution"""
        self._resolution = value
    
    @property
    def assigned_to(self) -> str:
        """Get assigned technician"""
        return self._assigned_to
    
    @assigned_to.setter
    def assigned_to(self, value: str):
        """Set assigned technician"""
        self._assigned_to = value
    
    # Special methods
    def __str__(self) -> str:
        """String representation"""
        return f"Ticket({self._ticket_id}, {self._employee_name}, {self._priority}, {self._status})"
    
    def __repr__(self) -> str:
        """Detailed representation"""
        return (f"Ticket(ticket_id='{self._ticket_id}', employee_name='{self._employee_name}', "
                f"department='{self._department}', category='{self._category}', "
                f"priority='{self._priority}', status='{self._status}')")
    
    def __eq__(self, other) -> bool:
        """Equality comparison"""
        if not isinstance(other, Ticket):
            return False
        return self._ticket_id == other.ticket_id
    
    # Instance methods
    def to_dict(self) -> Dict:
        """Convert ticket to dictionary"""
        return {
            'ticket_id': self._ticket_id,
            'employee_name': self._employee_name,
            'department': self._department,
            'issue_description': self._issue_description,
            'category': self._category,
            'priority': self._priority,
            'status': self._status,
            'created_date': self._created_date,
            'updated_date': self._updated_date,
            'resolved_date': self._resolved_date,
            'closed_date': self._closed_date,
            'resolution': self._resolution,
            'assigned_to': self._assigned_to,
            'notes': self._notes
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Ticket':
        """Create ticket from dictionary"""
        ticket = cls(
            ticket_id=data.get('ticket_id', ''),
            employee_name=data.get('employee_name', ''),
            department=data.get('department', ''),
            issue_description=data.get('issue_description', ''),
            category=data.get('category', ''),
            priority=data.get('priority', 'P4'),
            status=data.get('status', 'Open'),
            created_date=data.get('created_date')
        )
        ticket._updated_date = data.get('updated_date', ticket._created_date)
        ticket._resolved_date = data.get('resolved_date')
        ticket._closed_date = data.get('closed_date')
        ticket._resolution = data.get('resolution')
        ticket._assigned_to = data.get('assigned_to')
        ticket._notes = data.get('notes', [])
        return ticket
    
    def add_note(self, note: str):
        """Add a note to the ticket"""
        note_entry = {
            'timestamp': DateTimeHelper.get_current_datetime(),
            'note': note
        }
        self._notes.append(note_entry)
    
    def get_sla_hours(self) -> int:
        """Get SLA hours for this ticket's priority"""
        return DataProcessor.calculate_sla_hours(self._priority)
    
    def is_sla_breached(self) -> bool:
        """Check if SLA is breached"""
        if self._status in ['Resolved', 'Closed']:
            return False
        
        sla_hours = self.get_sla_hours()
        elapsed_hours = DateTimeHelper.calculate_hours_elapsed(self._created_date)
        
        if elapsed_hours > sla_hours:
            logger.log_sla_breach(self._ticket_id, sla_hours, elapsed_hours)
            return True
        return False
    
    def get_elapsed_hours(self) -> float:
        """Get hours since ticket creation"""
        return DateTimeHelper.calculate_hours_elapsed(self._created_date)
    
    # Static methods
    @staticmethod
    def get_priority_display(priority: str) -> str:
        """Get display name for priority"""
        display = {
            'P1': 'Critical',
            'P2': 'High',
            'P3': 'Medium',
            'P4': 'Low'
        }
        return display.get(priority, 'Unknown')
    
    @staticmethod
    def get_status_display(status: str) -> str:
        """Get display name for status"""
        display = {
            'Open': 'Open',
            'In Progress': 'In Progress',
            'Pending': 'Pending',
            'Resolved': 'Resolved',
            'Closed': 'Closed'
        }
        return display.get(status, 'Unknown')


class IncidentTicket(Ticket):
    """Incident Ticket class - inherits from Ticket for ITIL Incident Management"""
    
    # Class variable for incident types
    INCIDENT_TYPES = [
        'Server Down', 'Internet Down', 'Network Down', 'Application Crash',
        'System Failure', 'Service Outage', 'Security Incident', 'Data Loss'
    ]
    
    def __init__(self, ticket_id: str, employee_name: str, department: str,
                 issue_description: str, category: str, priority: str, status: str,
                 created_date: str = None, incident_type: str = None, 
                 impact_level: str = 'Medium', urgency: str = 'Medium'):
        """Constructor for Incident Ticket"""
        super().__init__(ticket_id, employee_name, department, issue_description,
                        category, priority, status, created_date)
        
        self._incident_type = incident_type or category
        self._impact_level = impact_level
        self._urgency = urgency
        self._root_cause = None
        self._impacted_users = 0
        self._service_affecting = False
    
    # Polymorphism - overridden properties
    @property
    def incident_type(self) -> str:
        """Get incident type"""
        return self._incident_type
    
    @incident_type.setter
    def incident_type(self, value: str):
        """Set incident type"""
        self._incident_type = value
    
    @property
    def impact_level(self) -> str:
        """Get impact level"""
        return self._impact_level
    
    @impact_level.setter
    def impact_level(self, value: str):
        """Set impact level"""
        if value not in ['Low', 'Medium', 'High', 'Critical']:
            raise ValueError("Impact level must be Low, Medium, High, or Critical")
        self._impact_level = value
    
    @property
    def urgency(self) -> str:
        """Get urgency"""
        return self._urgency
    
    @urgency.setter
    def urgency(self, value: str):
        """Set urgency"""
        if value not in ['Low', 'Medium', 'High', 'Critical']:
            raise ValueError("Urgency must be Low, Medium, High, or Critical")
        self._urgency = value
    
    @property
    def root_cause(self) -> str:
        """Get root cause"""
        return self._root_cause
    
    @root_cause.setter
    def root_cause(self, value: str):
        """Set root cause"""
        self._root_cause = value
    
    @property
    def impacted_users(self) -> int:
        """Get number of impacted users"""
        return self._impacted_users
    
    @impacted_users.setter
    def impacted_users(self, value: int):
        """Set number of impacted users"""
        self._impacted_users = value
    
    @property
    def service_affecting(self) -> bool:
        """Check if service is affecting"""
        return self._service_affecting
    
    @service_affecting.setter
    def service_affecting(self, value: bool):
        """Set service affecting flag"""
        self._service_affecting = value
    
    # Polymorphism - overridden method
    def to_dict(self) -> Dict:
        """Convert incident ticket to dictionary"""
        base_dict = super().to_dict()
        base_dict.update({
            'incident_type': self._incident_type,
            'impact_level': self._impact_level,
            'urgency': self._urgency,
            'root_cause': self._root_cause,
            'impacted_users': self._impacted_users,
            'service_affecting': self._service_affecting,
            'ticket_type': 'Incident'
        })
        return base_dict
    
    # Polymorphism - overridden method
    @classmethod
    def from_dict(cls, data: Dict) -> 'IncidentTicket':
        """Create incident ticket from dictionary"""
        ticket = cls(
            ticket_id=data.get('ticket_id', ''),
            employee_name=data.get('employee_name', ''),
            department=data.get('department', ''),
            issue_description=data.get('issue_description', ''),
            category=data.get('category', ''),
            priority=data.get('priority', 'P4'),
            status=data.get('status', 'Open'),
            created_date=data.get('created_date'),
            incident_type=data.get('incident_type'),
            impact_level=data.get('impact_level', 'Medium'),
            urgency=data.get('urgency', 'Medium')
        )
        ticket._updated_date = data.get('updated_date', ticket._created_date)
        ticket._resolved_date = data.get('resolved_date')
        ticket._closed_date = data.get('closed_date')
        ticket._resolution = data.get('resolution')
        ticket._assigned_to = data.get('assigned_to')
        ticket._notes = data.get('notes', [])
        ticket._root_cause = data.get('root_cause')
        ticket._impacted_users = data.get('impacted_users', 0)
        ticket._service_affecting = data.get('service_affecting', False)
        return ticket
    
    def __str__(self) -> str:
        """String representation"""
        return f"IncidentTicket({self._ticket_id}, {self._incident_type}, {self._priority})"


class ServiceRequest(Ticket):
    """Service Request class - inherits from Ticket for ITIL Service Request Management"""
    
    # Class variable for request types
    REQUEST_TYPES = [
        'Password Reset', 'Software Install', 'Hardware Request', 'Access Request',
        'Email Setup', 'VPN Access', 'New Employee Setup', 'Training Request'
    ]
    
    def __init__(self, ticket_id: str, employee_name: str, department: str,
                 issue_description: str, category: str, priority: str, status: str,
                 created_date: str = None, request_type: str = None,
                 requester_justification: str = None, approval_status: str = 'Pending'):
        """Constructor for Service Request"""
        super().__init__(ticket_id, employee_name, department, issue_description,
                        category, priority, status, created_date)
        
        self._request_type = request_type or category
        self._requester_justification = requester_justification
        self._approval_status = approval_status
        self._approved_by = None
        self._approved_date = None
        self._fulfillment_date = None
    
    # Polymorphism - overridden properties
    @property
    def request_type(self) -> str:
        """Get request type"""
        return self._request_type
    
    @request_type.setter
    def request_type(self, value: str):
        """Set request type"""
        self._request_type = value
    
    @property
    def requester_justification(self) -> str:
        """Get requester justification"""
        return self._requester_justification
    
    @requester_justification.setter
    def requester_justification(self, value: str):
        """Set requester justification"""
        self._requester_justification = value
    
    @property
    def approval_status(self) -> str:
        """Get approval status"""
        return self._approval_status
    
    @approval_status.setter
    def approval_status(self, value: str):
        """Set approval status"""
        if value not in ['Pending', 'Approved', 'Rejected']:
            raise ValueError("Approval status must be Pending, Approved, or Rejected")
        self._approval_status = value
    
    @property
    def approved_by(self) -> str:
        """Get approver name"""
        return self._approved_by
    
    @approved_by.setter
    def approved_by(self, value: str):
        """Set approver name"""
        self._approved_by = value
        if value:
            self._approved_date = DateTimeHelper.get_current_datetime()
    
    @property
    def approved_date(self) -> str:
        """Get approval date"""
        return self._approved_date
    
    @property
    def fulfillment_date(self) -> str:
        """Get fulfillment date"""
        return self._fulfillment_date
    
    @fulfillment_date.setter
    def fulfillment_date(self, value: str):
        """Set fulfillment date"""
        self._fulfillment_date = value
    
    # Polymorphism - overridden method
    def to_dict(self) -> Dict:
        """Convert service request to dictionary"""
        base_dict = super().to_dict()
        base_dict.update({
            'request_type': self._request_type,
            'requester_justification': self._requester_justification,
            'approval_status': self._approval_status,
            'approved_by': self._approved_by,
            'approved_date': self._approved_date,
            'fulfillment_date': self._fulfillment_date,
            'ticket_type': 'ServiceRequest'
        })
        return base_dict
    
    # Polymorphism - overridden method
    @classmethod
    def from_dict(cls, data: Dict) -> 'ServiceRequest':
        """Create service request from dictionary"""
        ticket = cls(
            ticket_id=data.get('ticket_id', ''),
            employee_name=data.get('employee_name', ''),
            department=data.get('department', ''),
            issue_description=data.get('issue_description', ''),
            category=data.get('category', ''),
            priority=data.get('priority', 'P4'),
            status=data.get('status', 'Open'),
            created_date=data.get('created_date'),
            request_type=data.get('request_type'),
            requester_justification=data.get('requester_justification'),
            approval_status=data.get('approval_status', 'Pending')
        )
        ticket._updated_date = data.get('updated_date', ticket._created_date)
        ticket._resolved_date = data.get('resolved_date')
        ticket._closed_date = data.get('closed_date')
        ticket._resolution = data.get('resolution')
        ticket._assigned_to = data.get('assigned_to')
        ticket._notes = data.get('notes', [])
        ticket._approved_by = data.get('approved_by')
        ticket._approved_date = data.get('approved_date')
        ticket._fulfillment_date = data.get('fulfillment_date')
        return ticket
    
    def approve(self, approver: str):
        """Approve the service request"""
        self._approval_status = 'Approved'
        self._approved_by = approver
        logger.info(f"Service Request {self._ticket_id} approved by {approver}")
    
    def reject(self, approver: str, reason: str):
        """Reject the service request"""
        self._approval_status = 'Rejected'
        self._approved_by = approver
        self.add_note(f"Rejected by {approver}: {reason}")
        logger.info(f"Service Request {self._ticket_id} rejected by {approver}")
    
    def __str__(self) -> str:
        """String representation"""
        return f"ServiceRequest({self._ticket_id}, {self._request_type}, {self._approval_status})"


class ProblemRecord:
    """Problem Record class for ITIL Problem Management"""
    
    def __init__(self, problem_id: str, title: str, description: str,
                 related_tickets: List[str] = None, root_cause: str = None,
                 status: str = 'Open', created_date: str = None):
        """Constructor for Problem Record"""
        self._problem_id = problem_id
        self._title = title
        self._description = description
        self._related_tickets = related_tickets or []
        self._root_cause = root_cause
        self._status = status
        self._created_date = created_date or DateTimeHelper.get_current_datetime()
        self._resolved_date = None
        self._resolution = None
        self._workaround = None
        self._known_error = False
    
    @property
    def problem_id(self) -> str:
        """Get problem ID"""
        return self._problem_id
    
    @property
    def title(self) -> str:
        """Get title"""
        return self._title
    
    @title.setter
    def title(self, value: str):
        """Set title"""
        self._title = value
    
    @property
    def description(self) -> str:
        """Get description"""
        return self._description
    
    @description.setter
    def description(self, value: str):
        """Set description"""
        self._description = value
    
    @property
    def related_tickets(self) -> List[str]:
        """Get related tickets"""
        return self._related_tickets
    
    @property
    def root_cause(self) -> str:
        """Get root cause"""
        return self._root_cause
    
    @root_cause.setter
    def root_cause(self, value: str):
        """Set root cause"""
        self._root_cause = value
    
    @property
    def status(self) -> str:
        """Get status"""
        return self._status
    
    @status.setter
    def status(self, value: str):
        """Set status"""
        self._status = value
        if value == 'Resolved':
            self._resolved_date = DateTimeHelper.get_current_datetime()
    
    @property
    def created_date(self) -> str:
        """Get created date"""
        return self._created_date
    
    @property
    def resolved_date(self) -> str:
        """Get resolved date"""
        return self._resolved_date
    
    @property
    def resolution(self) -> str:
        """Get resolution"""
        return self._resolution
    
    @resolution.setter
    def resolution(self, value: str):
        """Set resolution"""
        self._resolution = value
    
    @property
    def workaround(self) -> str:
        """Get workaround"""
        return self._workaround
    
    @workaround.setter
    def workaround(self, value: str):
        """Set workaround"""
        self._workaround = value
    
    @property
    def known_error(self) -> bool:
        """Check if known error"""
        return self._known_error
    
    @known_error.setter
    def known_error(self, value: bool):
        """Set known error flag"""
        self._known_error = value
    
    def add_related_ticket(self, ticket_id: str):
        """Add a related ticket"""
        if ticket_id not in self._related_tickets:
            self._related_tickets.append(ticket_id)
    
    def to_dict(self) -> Dict:
        """Convert problem record to dictionary"""
        return {
            'problem_id': self._problem_id,
            'title': self._title,
            'description': self._description,
            'related_tickets': self._related_tickets,
            'root_cause': self._root_cause,
            'status': self._status,
            'created_date': self._created_date,
            'resolved_date': self._resolved_date,
            'resolution': self._resolution,
            'workaround': self._workaround,
            'known_error': self._known_error
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ProblemRecord':
        """Create problem record from dictionary"""
        return cls(
            problem_id=data.get('problem_id', ''),
            title=data.get('title', ''),
            description=data.get('description', ''),
            related_tickets=data.get('related_tickets', []),
            root_cause=data.get('root_cause'),
            status=data.get('status', 'Open'),
            created_date=data.get('created_date')
        )
    
    def __str__(self) -> str:
        """String representation"""
        return f"ProblemRecord({self._problem_id}, {self._title}, {self._status})"


class TicketManager:
    """Ticket Manager class - handles all ticket operations"""
    
    def __init__(self, data_file: str = 'data/tickets.json'):
        """Constructor for Ticket Manager"""
        self._data_file = data_file
        self._tickets: List[Ticket] = []
        self._load_tickets()
    
    def _load_tickets(self):
        """Load tickets from JSON file"""
        try:
            data = FileHandler.read_json(self._data_file)
            if isinstance(data, list):
                for item in data:
                    ticket_type = item.get('ticket_type', 'Ticket')
                    if ticket_type == 'Incident':
                        self._tickets.append(IncidentTicket.from_dict(item))
                    elif ticket_type == 'ServiceRequest':
                        self._tickets.append(ServiceRequest.from_dict(item))
                    else:
                        self._tickets.append(Ticket.from_dict(item))
                
                # Update ID generator counters
                max_ticket_id = 0
                for ticket in self._tickets:
                    try:
                        ticket_num = int(ticket.ticket_id.split('-')[1])
                        if ticket_num > max_ticket_id:
                            max_ticket_id = ticket_num
                    except:
                        pass
                IDGenerator.set_counters(ticket_count=max_ticket_id)
                
                logger.info(f"Loaded {len(self._tickets)} tickets from {self._data_file}")
        except FileNotFoundError:
            logger.info("No existing tickets file found, starting fresh")
        except Exception as e:
            logger.error(f"Error loading tickets: {str(e)}")
    
    def _save_tickets(self):
        """Save tickets to JSON file"""
        data = [ticket.to_dict() for ticket in self._tickets]
        FileHandler.write_json(self._data_file, data)
        logger.info(f"Saved {len(self._tickets)} tickets to {self._data_file}")
    
    def create_ticket(self, employee_name: str, department: str,
                     issue_description: str, category: str, 
                     ticket_type: str = 'Ticket', **kwargs) -> Ticket:
        """Create a new ticket"""
        # Determine priority based on issue
        priority = kwargs.get('priority')
        if not priority:
            priority = DataProcessor.get_priority_from_issue(issue_description)
        
        # Generate ticket ID
        ticket_id = IDGenerator.generate_ticket_id()
        
        # Create appropriate ticket type
        if ticket_type == 'Incident':
            ticket = IncidentTicket(
                ticket_id=ticket_id,
                employee_name=employee_name,
                department=department,
                issue_description=issue_description,
                category=category,
                priority=priority,
                status='Open',
                incident_type=kwargs.get('incident_type'),
                impact_level=kwargs.get('impact_level', 'Medium'),
                urgency=kwargs.get('urgency', 'Medium')
            )
        elif ticket_type == 'ServiceRequest':
            ticket = ServiceRequest(
                ticket_id=ticket_id,
                employee_name=employee_name,
                department=department,
                issue_description=issue_description,
                category=category,
                priority=priority,
                status='Open',
                request_type=kwargs.get('request_type'),
                requester_justification=kwargs.get('justification'),
                approval_status=kwargs.get('approval_status', 'Pending')
            )
        else:
            ticket = Ticket(
                ticket_id=ticket_id,
                employee_name=employee_name,
                department=department,
                issue_description=issue_description,
                category=category,
                priority=priority,
                status='Open'
            )
        
        self._tickets.append(ticket)
        self._save_tickets()
        
        logger.log_ticket_created(ticket_id, employee_name, category)
        
        return ticket
    
    def get_all_tickets(self) -> List[Ticket]:
        """Get all tickets"""
        return self._tickets
    
    def get_ticket_by_id(self, ticket_id: str) -> Optional[Ticket]:
        """Search ticket by ID"""
        for ticket in self._tickets:
            if ticket.ticket_id == ticket_id:
                return ticket
        return None
    
    def search_tickets(self, query: str) -> List[Ticket]:
        """Search tickets by query"""
        results = []
        query_lower = query.lower()
        
        for ticket in self._tickets:
            search_fields = [
                ticket.ticket_id,
                ticket.employee_name,
                ticket.department,
                ticket.issue_description,
                ticket.category
            ]
            
            if any(query_lower in str(field).lower() for field in search_fields):
                results.append(ticket)
        
        return results
    
    def update_ticket_status(self, ticket_id: str, new_status: str, resolution: str = None) -> bool:
        """Update ticket status"""
        ticket = self.get_ticket_by_id(ticket_id)
        if not ticket:
            logger.error(f"Ticket not found: {ticket_id}")
            return False
        
        old_status = ticket.status
        ticket.status = new_status
        
        if new_status == 'Resolved' and resolution:
            ticket.resolution = resolution
        
        self._save_tickets()
        
        if new_status == 'Closed':
            logger.log_ticket_closed(ticket_id, ticket.resolution or 'N/A')
        
        return True
    
    def close_ticket(self, ticket_id: str, resolution: str = None) -> bool:
        """Close a ticket"""
        ticket = self.get_ticket_by_id(ticket_id)
        if not ticket:
            logger.error(f"Ticket not found: {ticket_id}")
            return False
        
        ticket.status = 'Closed'
        if resolution:
            ticket.resolution = resolution
        
        self._save_tickets()
        logger.log_ticket_closed(ticket_id, resolution or 'N/A')
        
        return True
    
    def delete_ticket(self, ticket_id: str) -> bool:
        """Delete a ticket"""
        ticket = self.get_ticket_by_id(ticket_id)
        if not ticket:
            logger.error(f"Ticket not found: {ticket_id}")
            return False
        
        self._tickets.remove(ticket)
        self._save_tickets()
        logger.info(f"Ticket deleted: {ticket_id}")
        
        return True
    
    def get_tickets_by_status(self, status: str) -> List[Ticket]:
        """Get tickets by status"""
        return [t for t in self._tickets if t.status == status]
    
    def get_tickets_by_priority(self, priority: str) -> List[Ticket]:
        """Get tickets by priority"""
        return [t for t in self._tickets if t.priority == priority]
    
    def get_tickets_by_department(self, department: str) -> List[Ticket]:
        """Get tickets by department"""
        return [t for t in self._tickets if t.department.lower() == department.lower()]
    
    def get_open_tickets(self) -> List[Ticket]:
        """Get all open tickets"""
        return [t for t in self._tickets if t.status in ['Open', 'In Progress', 'Pending']]
    
    def get_high_priority_tickets(self) -> List[Ticket]:
        """Get high priority tickets (P1, P2)"""
        return [t for t in self._tickets if t.priority in ['P1', 'P2']]
    
    def get_breached_sla_tickets(self) -> List[Ticket]:
        """Get tickets with breached SLA"""
        breached = []
        for ticket in self._tickets:
            if ticket.is_sla_breached():
                breached.append(ticket)
        return breached
    
    def sort_tickets(self, sort_by: str = 'created_date', 
                    reverse: bool = True) -> List[Ticket]:
        """Sort tickets"""
        ticket_dicts = [t.to_dict() for t in self._tickets]
        sorted_dicts = DataProcessor.sort_tickets(ticket_dicts, sort_by, reverse)
        
        # Convert back to Ticket objects
        return [Ticket.from_dict(d) for d in sorted_dicts]
    
    def get_ticket_count(self) -> Dict:
        """Get ticket count statistics"""
        return {
            'total': len(self._tickets),
            'open': len(self.get_tickets_by_status('Open')),
            'in_progress': len(self.get_tickets_by_status('In Progress')),
            'pending': len(self.get_tickets_by_status('Pending')),
            'resolved': len(self.get_tickets_by_status('Resolved')),
            'closed': len(self.get_tickets_by_status('Closed')),
            'p1': len(self.get_tickets_by_priority('P1')),
            'p2': len(self.get_tickets_by_priority('P2')),
            'p3': len(self.get_tickets_by_priority('P3')),
            'p4': len(self.get_tickets_by_priority('P4'))
        }
    
    def create_backup(self, backup_file: str = 'data/backup.csv'):
        """Create CSV backup of tickets"""
        fieldnames = ['ticket_id', 'employee_name', 'department', 'issue_description',
                     'category', 'priority', 'status', 'created_date', 'updated_date',
                     'resolved_date', 'closed_date', 'resolution']
        
        data = [ticket.to_dict() for ticket in self._tickets]
        
        # Flatten for CSV
        csv_data = []
        for ticket in data:
            row = {k: ticket.get(k, '') for k in fieldnames}
            csv_data.append(row)
        
        success = FileHandler.write_csv(backup_file, csv_data, fieldnames)
        if success:
            logger.info(f"Backup created: {backup_file}")
        
        return success