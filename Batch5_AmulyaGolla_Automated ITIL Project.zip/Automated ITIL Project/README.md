# IT Service Desk Automation System

A Python-based automation system for IT helpdesk support that replaces manual processes with an efficient, automated solution.

## 📋 Overview

This project implements a comprehensive IT Service Desk system using Python with a focus on:
- Core Python concepts
- Object-Oriented Programming (OOP)
- File Handling (JSON/CSV)
- Exception Handling
- System Monitoring
- ITIL Workflows

## 🏗️ Project Structure

```
smart_it_service_desk/
├── main.py              # Main entry point with CLI interface
├── tickets.py           # Ticket management module
├── monitor.py           # System monitoring module
├── reports.py           # Reports generation module
├── itil.py              # ITIL concepts implementation
├── utils.py             # Utility functions and helpers
├── logger.py            # Logging module
├── requirements.txt     # Python dependencies
├── README.md            # This file
└── data/
    ├── tickets.json     # Ticket data storage
    ├── problems.json    # Problem records storage
    ├── logs.txt         # Application logs
    └── backup.csv       # CSV backup of tickets
```

## ✨ Features

### 1. Ticket Management
- ✅ Create tickets with auto-generated IDs
- ✅ View all tickets
- ✅ Search tickets by ID or keywords
- ✅ Update ticket status
- ✅ Close tickets with resolution
- ✅ Delete tickets
- ✅ Filter by status, priority, department

### 2. Incident Management (ITIL)
- ✅ Create incident tickets
- ✅ Track impact and urgency
- ✅ Calculate priority automatically
- ✅ Resolve incidents with root cause
- ✅ View active and major incidents

### 3. Service Request Management (ITIL)
- ✅ Create service requests
- ✅ Approval workflow (Pending/Approved/Rejected)
- ✅ Fulfillment tracking
- ✅ Justification tracking

### 4. Problem Management (ITIL)
- ✅ Analyze repeated issues (5+ occurrences)
- ✅ Auto-create problem records
- ✅ Track related tickets
- ✅ Root cause analysis
- ✅ Workaround documentation

### 5. SLA Tracking (ITIL)
- ✅ Priority-based SLA rules:
  - P1: 1 hour
  - P2: 4 hours
  - P3: 8 hours
  - P4: 24 hours
- ✅ Breach detection
- ✅ Auto-escalation
- ✅ Compliance reporting

### 6. System Monitoring
- ✅ CPU usage monitoring (>90% alert)
- ✅ Memory usage monitoring (>95% alert)
- ✅ Disk space monitoring (<10% free alert)
- ✅ Auto ticket creation for alerts
- ✅ Alert history tracking

### 7. Reports
- ✅ Daily reports
- ✅ Monthly reports
- ✅ Summary reports
- ✅ Ticket trends
- ✅ Export to JSON/CSV

### 8. Backup & Logging
- ✅ Automatic CSV backup
- ✅ Comprehensive logging (INFO, WARNING, ERROR, CRITICAL)
- ✅ Log rotation support

## 🐍 Python Concepts Used

### Core Python
- Variables, Data Types, I/O
- Conditions, Loops, Functions
- String Handling, Operators

### Intermediate Python
- Lists, Tuples, Sets, Dictionaries
- List Comprehensions
- Modules and Packages

### Advanced Python
- Iterators and Generators
- Decorators (@property, @staticmethod)
- map(), filter(), reduce()
- JSON handling
- Regular Expressions

### OOP Concepts
- Classes: Ticket, IncidentTicket, ServiceRequest, ProblemRecord, Monitor, ReportGenerator
- Constructors and Objects
- Instance Variables
- Inheritance (IncidentTicket, ServiceRequest extend Ticket)
- Polymorphism (overridden methods)
- Encapsulation (private variables with @property)
- Static Methods
- Special Methods (__str__, __repr__, __eq__)

## 🚀 Getting Started

### Prerequisites
- Python 3.8 or higher
- psutil library (for system monitoring)

### Installation

1. Clone or download the project
2. Install dependencies:
```bash
pip install -r requirements.txt
```

Or install psutil manually:
```bash
pip install psutil
```

### Running the Application

```bash
python main.py
```

### Sample Data
The system automatically creates sample tickets on first run for demonstration purposes.

## 📊 Sample Ticket Data

| Employee | Department | Issue | Category | Priority |
|----------|------------|-------|----------|----------|
| John Smith | Engineering | Laptop running very slow | Laptop Slow | P3 |
| Jane Doe | Sales | Cannot connect to internet | Internet Down | P2 |
| Mike Johnson | HR | Password not working | Password Reset | P4 |
| Sarah Williams | Marketing | Printer not printing | Printer Failure | P3 |
| Tom Brown | Engineering | Server down | Server Down | P1 |

## 🎯 Priority Rules

| Issue Type | Priority |
|------------|----------|
| Server Down | P1 |
| Internet Down | P2 |
| Network Down | P2 |
| Laptop Slow | P3 |
| Printer Failure | P3 |
| Application Crash | P3 |
| Disk Full | P3 |
| High CPU | P3 |
| Password Reset | P4 |
| Software Install | P4 |

## 🧪 Testing

The system includes comprehensive error handling for:
- File not found errors
- Invalid input validation
- Invalid ticket IDs
- Empty values
- Duplicate records

## 📝 Log Levels

- **INFO**: Ticket created, updated, closed
- **WARNING**: Monitoring alerts, SLA breaches
- **ERROR**: Operation failures
- **CRITICAL**: System failures

## 📁 Data Files

### tickets.json
```json
[
  {
    "ticket_id": "TKT-000001",
    "employee_name": "John Smith",
    "department": "Engineering",
    "issue_description": "Laptop running slow",
    "category": "Laptop Slow",
    "priority": "P3",
    "status": "Open",
    "created_date": "2024-01-15 10:30:00"
  }
]
```

### backup.csv
```csv
ticket_id,employee_name,department,issue_description,category,priority,status,created_date
TKT-000001,John Smith,Engineering,Laptop running slow,Laptop Slow,P3,Open,2024-01-15 10:30:00
```

## 🔧 Configuration

### Monitoring Thresholds
Edit `monitor.py` to adjust thresholds:
```python
CPU_THRESHOLD = 90.0    # CPU alert threshold
MEMORY_THRESHOLD = 95.0 # Memory alert threshold
DISK_THRESHOLD = 10.0   # Minimum free disk space
```

### SLA Hours
Edit `itil.py` to modify SLA times:
```python
SLA_HOURS = {
    'P1': 1,   # 1 hour
    'P2': 4,   # 4 hours
    'P3': 8,   # 8 hours
    'P4': 24   # 24 hours
}
```

## 📈 Sample Output

```
============================================================
                    MAIN MENU
============================================================
1.  Ticket Management
2.  Incident Management
3.  Service Request Management
4.  Problem Management
5.  SLA Tracking
6.  System Monitoring
7.  Reports
8.  ITIL Summary
9.  Backup Data
0.  Exit
============================================================
```

## 🤝 Contributing

This is a demonstration project for IT Service Desk automation. Feel free to extend it with:
- Database integration (SQL)
- Web UI (Flask/Django)
- Email notifications
- REST API
- User authentication

## 📄 License

This project is for educational purposes.

## 👨‍💻 Author

Created as a comprehensive Python project demonstrating IT Service Desk automation with ITIL best practices.