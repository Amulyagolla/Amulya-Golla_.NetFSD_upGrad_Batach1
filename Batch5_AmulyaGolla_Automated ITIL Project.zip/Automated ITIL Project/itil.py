# filepath: itil.py
"""
ITIL Module for IT Service Desk
Handles Incident Management, Problem Management, Service Request, and SLA Tracking
"""

from datetime import datetime, timedelta
from typing import List, Dict, Optional
from collections import Counter
from utils import (
    FileHandler, DateTimeHelper, IDGenerator, DataProcessor
)
from logger import logger, INFO, WARNING, ERROR
from tickets import Ticket, IncidentTicket, ServiceRequest, ProblemRecord, TicketManager


class SLATracker:
    """SLA Tracking class for ITIL SLA Monitoring"""
    
    # SLA definitions (in hours)
    SLA_HOURS = {
        'P1': 1,   # Critical - 1 hour
        'P2': 4,   # High - 4 hours
        'P3': 8,   # Medium - 8 hours
        'P4': 24   # Low - 24 hours
    }
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize SLA Tracker"""
        self._ticket_manager = ticket_manager or TicketManager()
        self._breach_history: List[Dict] = []
    
    @property
    def breach_history(self) -> List[Dict]:
        """Get breach history"""
        return self._breach_history
    
    def get_sla_hours(self, priority: str) -> int:
        """Get SLA hours for priority"""
        return self.SLA_HOURS.get(priority, 24)
    
    def check_sla(self, ticket: Ticket) -> Dict:
        """Check SLA status for a ticket"""
        if ticket.status in ['Resolved', 'Closed']:
            return {
                'breached': False,
                'message': 'Ticket is closed'
            }
        
        sla_hours = self.get_sla_hours(ticket.priority)
        elapsed_hours = ticket.get_elapsed_hours()
        remaining_hours = sla_hours - elapsed_hours
        
        is_breached = elapsed_hours > sla_hours
        
        return {
            'breached': is_breached,
            'sla_hours': sla_hours,
            'elapsed_hours': round(elapsed_hours, 2),
            'remaining_hours': round(remaining_hours, 2),
            'priority': ticket.priority,
            'status': ticket.status
        }
    
    def get_all_breached_tickets(self) -> List[Ticket]:
        """Get all tickets with breached SLA"""
        breached = []
        tickets = self._ticket_manager.get_all_tickets()
        
        for ticket in tickets:
            sla_status = self.check_sla(ticket)
            if sla_status['breached']:
                breached.append(ticket)
                self._breach_history.append({
                    'ticket_id': ticket.ticket_id,
                    'breach_time': DateTimeHelper.get_current_datetime(),
                    'elapsed_hours': sla_status['elapsed_hours'],
                    'sla_hours': sla_status['sla_hours']
                })
        
        return breached
    
    def get_pending_tickets(self) -> List[Ticket]:
        """Get all pending tickets with SLA info"""
        pending = []
        tickets = self._ticket_manager.get_all_tickets()
        
        for ticket in tickets:
            if ticket.status not in ['Resolved', 'Closed']:
                sla_status = self.check_sla(ticket)
                pending.append({
                    'ticket': ticket,
                    'sla': sla_status
                })
        
        return pending
    
    def get_sla_compliance(self) -> Dict:
        """Get SLA compliance statistics"""
        tickets = self._ticket_manager.get_all_tickets()
        
        total = len(tickets)
        breached = len(self.get_all_breached_tickets())
        compliant = total - breached
        
        return {
            'total_tickets': total,
            'breached': breached,
            'compliant': compliant,
            'compliance_rate': round((compliant / total * 100), 2) if total > 0 else 100
        }
    
    def escalate_ticket(self, ticket: Ticket) -> bool:
        """Escalate a ticket based on SLA breach"""
        sla_status = self.check_sla(ticket)
        
        if sla_status['breached'] and ticket.status not in ['Resolved', 'Closed']:
            # Add escalation note
            ticket.add_note(f"SLA BREACHED: {sla_status['elapsed_hours']}h elapsed (SLA: {sla_status['sla_hours']}h)")
            
            # Escalate priority if not already P1
            if ticket.priority != 'P1':
                old_priority = ticket.priority
                ticket.priority = 'P1'
                ticket.add_note(f"Priority escalated from {old_priority} to P1 due to SLA breach")
                logger.warning(f"Priority escalated for {ticket.ticket_id}: {old_priority} -> P1")
            
            return True
        
        return False
    
    def get_sla_report(self) -> str:
        """Generate SLA report"""
        compliance = self.get_sla_compliance()
        breached = self.get_all_breached_tickets()
        pending = self.get_pending_tickets()
        
        report = f"""
=== SLA Report ===
Generated: {DateTimeHelper.get_current_datetime()}

Summary:
- Total Tickets: {compliance['total_tickets']}
- SLA Breaches: {compliance['breached']}
- Compliant: {compliance['compliant']}
- Compliance Rate: {compliance['compliance_rate']}%

Breached Tickets:
"""
        
        if breached:
            for ticket in breached:
                report += f"  - {ticket.ticket_id}: {ticket.issue_description[:50]}...\n"
        else:
            report += "  None\n"
        
        report += "\nPending Tickets (with SLA info):\n"
        for item in pending[:10]:  # Show first 10
            ticket = item['ticket']
            sla = item['sla']
            report += f"  - {ticket.ticket_id}: {sla['remaining_hours']}h remaining (Priority: {ticket.priority})\n"
        
        return report


class IncidentManager:
    """Incident Manager for ITIL Incident Management"""
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize Incident Manager"""
        self._ticket_manager = ticket_manager or TicketManager()
    
    def create_incident(self, employee_name: str, department: str,
                       issue_description: str, incident_type: str,
                       impact_level: str = 'Medium', urgency: str = 'Medium',
                       impacted_users: int = 0) -> IncidentTicket:
        """Create a new incident ticket"""
        # Determine priority based on impact and urgency
        priority = self._calculate_priority(impact_level, urgency)
        
        ticket = self._ticket_manager.create_ticket(
            employee_name=employee_name,
            department=department,
            issue_description=issue_description,
            category=incident_type,
            ticket_type='Incident',
            priority=priority,
            incident_type=incident_type,
            impact_level=impact_level,
            urgency=urgency
        )
        
        # Set impacted users
        if isinstance(ticket, IncidentTicket):
            ticket.impacted_users = impacted_users
            if impacted_users > 10:
                ticket.service_affecting = True
        
        logger.info(f"Incident created: {ticket.ticket_id} - {incident_type}")
        return ticket
    
    def _calculate_priority(self, impact_level: str, urgency: str) -> str:
        """Calculate priority based on impact and urgency"""
        # Matrix: Impact + Urgency = Priority
        priority_matrix = {
            ('Critical', 'Critical'): 'P1',
            ('Critical', 'High'): 'P1',
            ('High', 'Critical'): 'P1',
            ('High', 'High'): 'P2',
            ('High', 'Medium'): 'P2',
            ('Medium', 'High'): 'P2',
            ('Critical', 'Medium'): 'P2',
            ('Medium', 'Medium'): 'P3',
            ('Medium', 'Low'): 'P3',
            ('Low', 'Medium'): 'P3',
            ('Low', 'Low'): 'P4',
            ('Low', 'High'): 'P3',
            ('High', 'Low'): 'P3'
        }
        
        return priority_matrix.get((impact_level, urgency), 'P3')
    
    def resolve_incident(self, ticket_id: str, resolution: str, 
                        root_cause: str = None) -> bool:
        """Resolve an incident"""
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if not ticket:
            logger.error(f"Incident not found: {ticket_id}")
            return False
        
        if not isinstance(ticket, IncidentTicket):
            logger.error(f"Ticket {ticket_id} is not an incident")
            return False
        
        ticket.status = 'Resolved'
        ticket.resolution = resolution
        
        if root_cause:
            ticket.root_cause = root_cause
        
        self._ticket_manager._save_tickets()
        
        logger.info(f"Incident resolved: {ticket_id}")
        return True
    
    def get_active_incidents(self) -> List[IncidentTicket]:
        """Get all active incidents"""
        tickets = self._ticket_manager.get_all_tickets()
        return [t for t in tickets if isinstance(t, IncidentTicket) 
                and t.status not in ['Resolved', 'Closed']]
    
    def get_major_incidents(self) -> List[IncidentTicket]:
        """Get major incidents (P1/P2 or service affecting)"""
        tickets = self._ticket_manager.get_all_tickets()
        return [t for t in tickets if isinstance(t, IncidentTicket)
                and (t.priority in ['P1', 'P2'] or t.service_affecting)]


class ServiceRequestManager:
    """Service Request Manager for ITIL Service Request Management"""
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize Service Request Manager"""
        self._ticket_manager = ticket_manager or TicketManager()
    
    def create_request(self, employee_name: str, department: str,
                      issue_description: str, request_type: str,
                      justification: str = None) -> ServiceRequest:
        """Create a new service request"""
        ticket = self._ticket_manager.create_ticket(
            employee_name=employee_name,
            department=department,
            issue_description=issue_description,
            category=request_type,
            ticket_type='ServiceRequest',
            priority='P4',  # Service requests are typically low priority
            request_type=request_type,
            justification=justification,
            approval_status='Pending'
        )
        
        logger.info(f"Service request created: {ticket.ticket_id} - {request_type}")
        return ticket
    
    def approve_request(self, ticket_id: str, approver: str) -> bool:
        """Approve a service request"""
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if not ticket:
            logger.error(f"Request not found: {ticket_id}")
            return False
        
        if not isinstance(ticket, ServiceRequest):
            logger.error(f"Ticket {ticket_id} is not a service request")
            return False
        
        ticket.approve(approver)
        self._ticket_manager._save_tickets()
        
        logger.info(f"Service request approved: {ticket_id} by {approver}")
        return True
    
    def reject_request(self, ticket_id: str, approver: str, reason: str) -> bool:
        """Reject a service request"""
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if not ticket:
            logger.error(f"Request not found: {ticket_id}")
            return False
        
        if not isinstance(ticket, ServiceRequest):
            logger.error(f"Ticket {ticket_id} is not a service request")
            return False
        
        ticket.reject(approver, reason)
        self._ticket_manager._save_tickets()
        
        logger.info(f"Service request rejected: {ticket_id} by {approver}")
        return True
    
    def fulfill_request(self, ticket_id: str) -> bool:
        """Mark a service request as fulfilled"""
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if not ticket or not isinstance(ticket, ServiceRequest):
            return False
        
        if ticket.approval_status != 'Approved':
            logger.warning(f"Request {ticket_id} not approved yet")
            return False
        
        ticket.status = 'Resolved'
        ticket.fulfillment_date = DateTimeHelper.get_current_datetime()
        self._ticket_manager._save_tickets()
        
        logger.info(f"Service request fulfilled: {ticket_id}")
        return True
    
    def get_pending_requests(self) -> List[ServiceRequest]:
        """Get all pending service requests"""
        tickets = self._ticket_manager.get_all_tickets()
        return [t for t in tickets if isinstance(t, ServiceRequest)
                and t.approval_status == 'Pending']
    
    def get_approved_requests(self) -> List[ServiceRequest]:
        """Get all approved service requests"""
        tickets = self._ticket_manager.get_all_tickets()
        return [t for t in tickets if isinstance(t, ServiceRequest)
                and t.approval_status == 'Approved']


class ProblemManager:
    """Problem Manager for ITIL Problem Management"""
    
    def __init__(self, ticket_manager: TicketManager = None,
                 problem_file: str = 'data/problems.json'):
        """Initialize Problem Manager"""
        self._ticket_manager = ticket_manager or TicketManager()
        self._problem_file = problem_file
        self._problems: List[ProblemRecord] = []
        self._load_problems()
    
    def _load_problems(self):
        """Load problems from file"""
        try:
            data = FileHandler.read_json(self._problem_file)
            if isinstance(data, list):
                self._problems = [ProblemRecord.from_dict(p) for p in data]
                
                # Update counter
                max_id = 0
                for p in self._problems:
                    try:
                        num = int(p.problem_id.split('-')[1])
                        if num > max_id:
                            max_id = num
                    except:
                        pass
                IDGenerator.set_counters(problem_count=max_id)
                
                logger.info(f"Loaded {len(self._problems)} problem records")
        except FileNotFoundError:
            logger.info("No existing problems file found")
    
    def _save_problems(self):
        """Save problems to file"""
        data = [p.to_dict() for p in self._problems]
        FileHandler.write_json(self._problem_file, data)
    
    def analyze_repeated_issues(self, threshold: int = 5) -> List[Dict]:
        """Analyze tickets to find repeated issues"""
        tickets = self._ticket_manager.get_all_tickets()
        
        # Count by category
        category_count = Counter()
        issue_descriptions = []
        
        for ticket in tickets:
            category_count[ticket.category] += 1
            issue_descriptions.append(ticket.issue_description.lower())
        
        # Find repeated categories
        repeated = []
        for category, count in category_count.items():
            if count >= threshold:
                repeated.append({
                    'category': category,
                    'count': count,
                    'threshold': threshold
                })
        
        return repeated
    
    def create_problem_from_repeated_issues(self, category: str = None) -> Optional[ProblemRecord]:
        """Create a problem record if same issue occurs 5+ times"""
        repeated = self.analyze_repeated_issues()
        
        target_category = category
        if not target_category and repeated:
            target_category = repeated[0]['category']
        
        if not target_category:
            return None
        
        # Get all tickets for this category
        tickets = self._ticket_manager.get_tickets_by_category(target_category)
        
        if len(tickets) < 5:
            return None
        
        # Create problem record
        problem_id = IDGenerator.generate_problem_id()
        
        problem = ProblemRecord(
            problem_id=problem_id,
            title=f"Recurring Issue: {target_category}",
            description=f"Issue '{target_category}' has occurred {len(tickets)} times",
            related_tickets=[t.ticket_id for t in tickets],
            status='Open'
        )
        
        self._problems.append(problem)
        self._save_problems()
        
        logger.info(f"Problem record created: {problem_id} for category '{target_category}'")
        return problem
    
    def get_all_problems(self) -> List[ProblemRecord]:
        """Get all problem records"""
        return self._problems
    
    def get_problem_by_id(self, problem_id: str) -> Optional[ProblemRecord]:
        """Get problem by ID"""
        for problem in self._problems:
            if problem.problem_id == problem_id:
                return problem
        return None
    
    def update_problem_status(self, problem_id: str, status: str,
                             resolution: str = None, root_cause: str = None) -> bool:
        """Update problem status"""
        problem = self.get_problem_by_id(problem_id)
        
        if not problem:
            logger.error(f"Problem not found: {problem_id}")
            return False
        
        problem.status = status
        
        if resolution:
            problem.resolution = resolution
        
        if root_cause:
            problem.root_cause = root_cause
        
        self._save_problems()
        
        logger.info(f"Problem updated: {problem_id} - {status}")
        return True
    
    def add_workaround(self, problem_id: str, workaround: str):
        """Add a workaround for a problem"""
        problem = self.get_problem_by_id(problem_id)
        
        if problem:
            problem.workaround = workaround
            problem.known_error = True
            self._save_problems()
            logger.info(f"Workaround added to problem: {problem_id}")


class ChangeManager:
    """Change Manager for ITIL Change Management"""
    
    def __init__(self):
        """Initialize Change Manager"""
        self._changes: List[Dict] = []
    
    def create_change_record(self, change_id: str, title: str, description: str,
                            change_type: str, requested_by: str,
                            impact: str = 'Medium', risk: str = 'Low') -> Dict:
        """Create a change record"""
        change = {
            'change_id': f"CHG-{change_id}",
            'title': title,
            'description': description,
            'change_type': change_type,
            'requested_by': requested_by,
            'impact': impact,
            'risk': risk,
            'status': 'Pending',
            'created_date': DateTimeHelper.get_current_datetime(),
            'approved_date': None,
            'implemented_date': None
        }
        
        self._changes.append(change)
        logger.info(f"Change record created: {change['change_id']}")
        
        return change
    
    def approve_change(self, change_id: str, approver: str) -> bool:
        """Approve a change"""
        for change in self._changes:
            if change['change_id'] == change_id:
                change['status'] = 'Approved'
                change['approved_by'] = approver
                change['approved_date'] = DateTimeHelper.get_current_datetime()
                logger.info(f"Change approved: {change_id}")
                return True
        return False
    
    def implement_change(self, change_id: str) -> bool:
        """Mark change as implemented"""
        for change in self._changes:
            if change['change_id'] == change_id:
                change['status'] = 'Implemented'
                change['implemented_date'] = DateTimeHelper.get_current_datetime()
                logger.info(f"Change implemented: {change_id}")
                return True
        return False
    
    def get_all_changes(self) -> List[Dict]:
        """Get all change records"""
        return self._changes


class ITILService:
    """Unified ITIL Service class"""
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize ITIL Service"""
        self._ticket_manager = ticket_manager or TicketManager()
        self._sla_tracker = SLATracker(self._ticket_manager)
        self._incident_manager = IncidentManager(self._ticket_manager)
        self._service_request_manager = ServiceRequestManager(self._ticket_manager)
        self._problem_manager = ProblemManager(self._ticket_manager)
        self._change_manager = ChangeManager()
    
    @property
    def sla_tracker(self) -> SLATracker:
        """Get SLA tracker"""
        return self._sla_tracker
    
    @property
    def incident_manager(self) -> IncidentManager:
        """Get incident manager"""
        return self._incident_manager
    
    @property
    def service_request_manager(self) -> ServiceRequestManager:
        """Get service request manager"""
        return self._service_request_manager
    
    @property
    def problem_manager(self) -> ProblemManager:
        """Get problem manager"""
        return self._problem_manager
    
    @property
    def change_manager(self) -> ChangeManager:
        """Get change manager"""
        return self._change_manager
    
    def run_problem_analysis(self):
        """Run automatic problem analysis"""
        repeated = self._problem_manager.analyze_repeated_issues()
        
        for item in repeated:
            category = item['category']
            if not self._problem_manager.get_all_problems():
                self._problem_manager.create_problem_from_repeated_issues(category)
        
        return repeated
    
    def get_itil_summary(self) -> str:
        """Get ITIL operations summary"""
        incidents = self._incident_manager.get_active_incidents()
        requests = self._service_request_manager.get_pending_requests()
        problems = self._problem_manager.get_all_problems()
        sla = self._sla_tracker.get_sla_compliance()
        
        return f"""
=== ITIL Operations Summary ===
Generated: {DateTimeHelper.get_current_datetime()}

Incidents:
- Active Incidents: {len(incidents)}
- Major Incidents: {len([i for i in incidents if i.priority in ['P1', 'P2']])}

Service Requests:
- Pending Approval: {len(requests)}
- Approved: {len(self._service_request_manager.get_approved_requests())}

Problems:
- Total Problems: {len(problems)}
- Open Problems: {len([p for p in problems if p.status == 'Open'])}

SLA:
- Compliance Rate: {sla['compliance_rate']}%
- Breaches: {sla['breached']}
"""