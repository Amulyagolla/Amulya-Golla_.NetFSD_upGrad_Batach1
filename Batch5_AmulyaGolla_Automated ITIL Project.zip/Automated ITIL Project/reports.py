# filepath: reports.py
"""
Reports Module for IT Service Desk
Generates daily and monthly reports
"""

from datetime import datetime, timedelta
from typing import List, Dict, Optional
from collections import Counter
from utils import FileHandler, DateTimeHelper, DataProcessor
from logger import logger, INFO
from tickets import TicketManager


class ReportGenerator:
    """Report Generator class for creating various reports"""
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize Report Generator"""
        self._ticket_manager = ticket_manager or TicketManager()
    
    def generate_daily_report(self, date: str = None) -> Dict:
        """Generate daily report"""
        if not date:
            date = DateTimeHelper.get_current_date()
        
        tickets = self._ticket_manager.get_all_tickets()
        
        # Filter tickets for the specified date
        daily_tickets = [
            t for t in tickets 
            if t.created_date.startswith(date)
        ]
        
        # Calculate statistics
        total = len(daily_tickets)
        open_count = len([t for t in daily_tickets if t.status == 'Open'])
        in_progress = len([t for t in daily_tickets if t.status == 'In Progress'])
        pending = len([t for t in daily_tickets if t.status == 'Pending'])
        resolved = len([t for t in daily_tickets if t.status == 'Resolved'])
        closed = len([t for t in daily_tickets if t.status == 'Closed'])
        
        # Priority breakdown
        p1 = len([t for t in daily_tickets if t.priority == 'P1'])
        p2 = len([t for t in daily_tickets if t.priority == 'P2'])
        p3 = len([t for t in daily_tickets if t.priority == 'P3'])
        p4 = len([t for t in daily_tickets if t.priority == 'P4'])
        
        # SLA breaches
        sla_breaches = len([t for t in daily_tickets if t.is_sla_breached()])
        
        # Category breakdown
        categories = Counter([t.category for t in daily_tickets])
        
        report = {
            'report_type': 'Daily',
            'date': date,
            'total_tickets': total,
            'open_tickets': open_count,
            'in_progress_tickets': in_progress,
            'pending_tickets': pending,
            'resolved_tickets': resolved,
            'closed_tickets': closed,
            'high_priority_tickets': p1 + p2,
            'p1_tickets': p1,
            'p2_tickets': p2,
            'p3_tickets': p3,
            'p4_tickets': p4,
            'sla_breaches': sla_breaches,
            'categories': dict(categories)
        }
        
        logger.info(f"Daily report generated for {date}")
        return report
    
    def generate_monthly_report(self, year: int = None, month: int = None) -> Dict:
        """Generate monthly report"""
        if not year:
            year = datetime.now().year
        if not month:
            month = datetime.now().month
        
        tickets = self._ticket_manager.get_all_tickets()
        
        # Filter tickets for the specified month
        month_prefix = f"{year}-{month:02d}"
        monthly_tickets = [
            t for t in tickets 
            if t.created_date.startswith(month_prefix)
        ]
        
        # Calculate statistics
        total = len(monthly_tickets)
        
        if total == 0:
            return {
                'report_type': 'Monthly',
                'year': year,
                'month': month,
                'total_tickets': 0,
                'message': 'No tickets for this month'
            }
        
        # Status breakdown
        status_counts = Counter([t.status for t in monthly_tickets])
        
        # Priority breakdown
        priority_counts = Counter([t.priority for t in monthly_tickets])
        
        # Department breakdown
        department_counts = Counter([t.department for t in monthly_tickets])
        
        # Category breakdown (most common issue)
        category_counts = Counter([t.category for t in monthly_tickets])
        most_common_issue = category_counts.most_common(1)[0] if category_counts else (None, 0)
        
        # Calculate average resolution time
        resolved_tickets = [t for t in monthly_tickets if t.resolved_date]
        if resolved_tickets:
            total_resolution_time = 0
            for t in resolved_tickets:
                created = DateTimeHelper.parse_datetime(t.created_date)
                resolved = DateTimeHelper.parse_datetime(t.resolved_date)
                total_resolution_time += (resolved - created).total_seconds() / 3600
            
            avg_resolution_hours = total_resolution_time / len(resolved_tickets)
        else:
            avg_resolution_hours = 0
        
        # Department with most incidents
        top_department = department_counts.most_common(1)[0] if department_counts else (None, 0)
        
        # Repeated problems
        repeated_problems = []
        for category, count in category_counts.items():
            if count >= 3:
                repeated_problems.append({
                    'category': category,
                    'count': count
                })
        
        report = {
            'report_type': 'Monthly',
            'year': year,
            'month': month,
            'total_tickets': total,
            'status_breakdown': dict(status_counts),
            'priority_breakdown': dict(priority_counts),
            'department_breakdown': dict(department_counts),
            'most_common_issue': {
                'category': most_common_issue[0],
                'count': most_common_issue[1]
            },
            'avg_resolution_hours': round(avg_resolution_hours, 2),
            'department_with_most_incidents': {
                'department': top_department[0],
                'count': top_department[1]
            },
            'repeated_problems': repeated_problems
        }
        
        logger.info(f"Monthly report generated for {year}-{month:02d}")
        return report
    
    def generate_summary_report(self) -> Dict:
        """Generate overall summary report"""
        tickets = self._ticket_manager.get_all_tickets()
        count = self._ticket_manager.get_ticket_count()
        
        # Category breakdown
        categories = Counter([t.category for t in tickets])
        
        # Department breakdown
        departments = Counter([t.department for t in tickets])
        
        # SLA compliance
        breached = self._ticket_manager.get_breached_sla_tickets()
        
        report = {
            'report_type': 'Summary',
            'generated_date': DateTimeHelper.get_current_datetime(),
            'total_tickets': count['total'],
            'open_tickets': count['open'],
            'closed_tickets': count['closed'],
            'high_priority_open': count['p1'] + count['p2'],
            'sla_breaches': len(breached),
            'top_categories': categories.most_common(5),
            'top_departments': departments.most_common(5)
        }
        
        return report
    
    def format_daily_report(self, report: Dict) -> str:
        """Format daily report as string"""
        return f"""
╔══════════════════════════════════════════════════════════════╗
║                    DAILY TICKET REPORT                       ║
║                    Date: {report['date']}                       ║
╚══════════════════════════════════════════════════════════════╝

SUMMARY
───────
Total Tickets:        {report['total_tickets']}
Open:                 {report['open_tickets']}
In Progress:          {report['in_progress_tickets']}
Pending:              {report['pending_tickets']}
Resolved:             {report['resolved_tickets']}
Closed:               {report['closed_tickets']}

PRIORITY BREAKDOWN
──────────────────
P1 (Critical):        {report['p1_tickets']}
P2 (High):            {report['p2_tickets']}
P3 (Medium):          {report['p3_tickets']}
P4 (Low):             {report['p4_tickets']}

SLA
───
SLA Breaches:         {report['sla_breaches']}

CATEGORIES
──────────
"""
    
    def format_daily_report_continued(self, report: Dict) -> str:
        """Continue formatting daily report"""
        output = ""
        for category, count in report.get('categories', {}).items():
            output += f"{category}: {count}\n"
        return output
    
    def format_monthly_report(self, report: Dict) -> str:
        """Format monthly report as string"""
        return f"""
╔══════════════════════════════════════════════════════════════╗
║                   MONTHLY TICKET REPORT                      ║
║                   {report['year']}-{report['month']:02d}                              ║
╚══════════════════════════════════════════════════════════════╝

SUMMARY
───────
Total Tickets:        {report['total_tickets']}

STATUS BREAKDOWN
───────────────
"""
    
    def format_monthly_report_continued(self, report: Dict) -> str:
        """Continue formatting monthly report"""
        output = ""
        for status, count in report.get('status_breakdown', {}).items():
            output += f"{status}: {count}\n"
        
        output += f"""
MOST COMMON ISSUE
─────────────────
{report.get('most_common_issue', {}).get('category', 'N/A')}: {report.get('most_common_issue', {}).get('count', 0)} occurrences

AVERAGE RESOLUTION TIME
───────────────────────
{report.get('avg_resolution_hours', 0)} hours

DEPARTMENT WITH MOST INCIDENTS
──────────────────────────────
{report.get('department_with_most_incidents', {}).get('department', 'N/A')}: {report.get('department_with_most_incidents', {}).get('count', 0)} tickets
"""
        
        if report.get('repeated_problems'):
            output += "\nREPEATED PROBLEMS (3+ occurrences)\n"
            for problem in report['repeated_problems']:
                output += f"  - {problem['category']}: {problem['count']} times\n"
        
        return output
    
    def save_report_to_file(self, report: Dict, filename: str) -> bool:
        """Save report to JSON file"""
        try:
            FileHandler.write_json(filename, report)
            logger.info(f"Report saved to {filename}")
            return True
        except Exception as e:
            logger.error(f"Failed to save report: {str(e)}")
            return False
    
    def export_report_to_csv(self, report: Dict, filename: str) -> bool:
        """Export report to CSV file"""
        try:
            # Flatten report for CSV
            rows = []
            
            if report['report_type'] == 'Daily':
                rows.append({
                    'metric': 'Total Tickets',
                    'value': report['total_tickets']
                })
                rows.append({'metric': 'Open', 'value': report['open_tickets']})
                rows.append({'metric': 'In Progress', 'value': report['in_progress_tickets']})
                rows.append({'metric': 'Pending', 'value': report['pending_tickets']})
                rows.append({'metric': 'Resolved', 'value': report['resolved_tickets']})
                rows.append({'metric': 'Closed', 'value': report['closed_tickets']})
                rows.append({'metric': 'P1', 'value': report['p1_tickets']})
                rows.append({'metric': 'P2', 'value': report['p2_tickets']})
                rows.append({'metric': 'P3', 'value': report['p3_tickets']})
                rows.append({'metric': 'P4', 'value': report['p4_tickets']})
                rows.append({'metric': 'SLA Breaches', 'value': report['sla_breaches']})
            
            FileHandler.write_csv(filename, rows, ['metric', 'value'])
            logger.info(f"Report exported to {filename}")
            return True
        except Exception as e:
            logger.error(f"Failed to export report: {str(e)}")
            return False


class ReportScheduler:
    """Schedule and generate automated reports"""
    
    def __init__(self, ticket_manager: TicketManager = None):
        """Initialize Report Scheduler"""
        self._ticket_manager = ticket_manager or TicketManager()
        self._report_generator = ReportGenerator(self._ticket_manager)
        self._scheduled_reports: List[Dict] = []
    
    def schedule_daily_report(self, time: str = '09:00'):
        """Schedule daily report generation"""
        schedule = {
            'type': 'daily',
            'time': time,
            'enabled': True
        }
        self._scheduled_reports.append(schedule)
        logger.info(f"Daily report scheduled at {time}")
    
    def schedule_monthly_report(self, day: int = 1, time: str = '09:00'):
        """Schedule monthly report generation"""
        schedule = {
            'type': 'monthly',
            'day': day,
            'time': time,
            'enabled': True
        }
        self._scheduled_reports.append(schedule)
        logger.info(f"Monthly report scheduled for day {day} at {time}")
    
    def generate_all_scheduled(self):
        """Generate all scheduled reports"""
        results = []
        
        for schedule in self._scheduled_reports:
            if not schedule['enabled']:
                continue
            
            if schedule['type'] == 'daily':
                report = self._report_generator.generate_daily_report()
                results.append(report)
            elif schedule['type'] == 'monthly':
                report = self._report_generator.generate_monthly_report()
                results.append(report)
        
        return results
    
    def get_scheduled_reports(self) -> List[Dict]:
        """Get list of scheduled reports"""
        return self._scheduled_reports


# Standalone functions for quick report generation
def generate_quick_report(ticket_manager: TicketManager = None) -> str:
    """Generate a quick summary report"""
    generator = ReportGenerator(ticket_manager)
    report = generator.generate_summary_report()
    
    output = f"""
=== QUICK SUMMARY REPORT ===
Generated: {report['generated_date']}

Total Tickets: {report['total_tickets']}
Open: {report['open_tickets']}
Closed: {report['closed_tickets']}
High Priority Open: {report['high_priority_open']}
SLA Breaches: {report['sla_breaches']}

Top 5 Categories:
"""
    
    for category, count in report['top_categories']:
        output += f"  {category}: {count}\n"
    
    output += "\nTop 5 Departments:\n"
    for dept, count in report['top_departments']:
        output += f"  {dept}: {count}\n"
    
    return output


def get_ticket_trends(ticket_manager: TicketManager = None, days: int = 7) -> Dict:
    """Get ticket trends for the last N days"""
    generator = ReportGenerator(ticket_manager)
    
    trends = []
    for i in range(days):
        date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
        report = generator.generate_daily_report(date)
        trends.append({
            'date': date,
            'total': report['total_tickets'],
            'open': report['open_tickets'],
            'closed': report['closed_tickets']
        })
    
    return {
        'days': days,
        'trends': trends
    }