# filepath: logger.py
"""
Logging Module for IT Service Desk
Handles all logging operations with different log levels
"""

import logging
from datetime import datetime
from pathlib import Path

# Constants for log levels
INFO = "INFO"
WARNING = "WARNING"
ERROR = "ERROR"
CRITICAL = "CRITICAL"

class ServiceDeskLogger:
    """Custom logger for IT Service Desk operations"""
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern to ensure single logger instance"""
        if cls._instance is None:
            cls._instance = super(ServiceDeskLogger, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize the logger with file and console handlers"""
        if self._initialized:
            return
            
        self.log_file = Path("data/logs.txt")
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Configure logging
        self.logger = logging.getLogger("ITServiceDesk")
        self.logger.setLevel(logging.DEBUG)
        
        # Clear existing handlers
        self.logger.handlers.clear()
        
        # File handler
        file_handler = logging.FileHandler(self.log_file, mode='a')
        file_handler.setLevel(logging.DEBUG)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        self._initialized = True
    
    def log(self, level: str, message: str):
        """Log a message at the specified level"""
        log_methods = {
            INFO: self.logger.info,
            WARNING: self.logger.warning,
            ERROR: self.logger.error,
            CRITICAL: self.logger.critical
        }
        
        log_method = log_methods.get(level, self.logger.info)
        log_method(message)
    
    def info(self, message: str):
        """Log info message"""
        self.log(INFO, message)
    
    def warning(self, message: str):
        """Log warning message"""
        self.log(WARNING, message)
    
    def error(self, message: str):
        """Log error message"""
        self.log(ERROR, message)
    
    def critical(self, message: str):
        """Log critical message"""
        self.log(CRITICAL, message)
    
    def log_ticket_created(self, ticket_id: str, employee_name: str, category: str):
        """Log ticket creation"""
        self.info(f"TICKET CREATED: ID={ticket_id}, Employee={employee_name}, Category={category}")
    
    def log_ticket_updated(self, ticket_id: str, old_status: str, new_status: str):
        """Log ticket update"""
        self.info(f"TICKET UPDATED: ID={ticket_id}, Status: {old_status} -> {new_status}")
    
    def log_ticket_closed(self, ticket_id: str, resolution: str):
        """Log ticket closure"""
        self.info(f"TICKET CLOSED: ID={ticket_id}, Resolution={resolution}")
    
    def log_monitoring_alert(self, alert_type: str, value: float, threshold: float):
        """Log monitoring alert"""
        self.warning(f"MONITORING ALERT: {alert_type}={value}% (threshold={threshold}%)")
    
    def log_sla_breach(self, ticket_id: str, sla_hours: int, elapsed_hours: float):
        """Log SLA breach"""
        self.warning(f"SLA BREACH: Ticket={ticket_id}, SLA={sla_hours}h, Elapsed={elapsed_hours:.2f}h")
    
    def log_error(self, error_type: str, details: str):
        """Log error with details"""
        self.error(f"ERROR: {error_type} - {details}")


# Global logger instance
logger = ServiceDeskLogger()