# filepath: utils.py
"""
Utility Module for IT Service Desk
Contains helper functions for file operations, validation, and data processing
"""

import json
import csv
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from pathlib import Path
from logger import logger, INFO, ERROR


class FileHandler:
    """Handles all file operations for the IT Service Desk"""
    
    @staticmethod
    def read_json(file_path: str) -> Any:
        """Read and parse JSON file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            raise FileNotFoundError(f"File not found: {file_path}")
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in {file_path}: {str(e)}")
            raise ValueError(f"Invalid JSON format: {str(e)}")
    
    @staticmethod
    def write_json(file_path: str, data: Any) -> bool:
        """Write data to JSON file"""
        try:
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Failed to write JSON to {file_path}: {str(e)}")
            return False
    
    @staticmethod
    def append_json(file_path: str, data: Any) -> bool:
        """Append data to JSON file (list)"""
        try:
            existing_data = []
            if Path(file_path).exists():
                existing_data = FileHandler.read_json(file_path)
                if not isinstance(existing_data, list):
                    existing_data = [existing_data]
            else:
                Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            if isinstance(data, list):
                existing_data.extend(data)
            else:
                existing_data.append(data)
            
            return FileHandler.write_json(file_path, existing_data)
        except Exception as e:
            logger.error(f"Failed to append JSON to {file_path}: {str(e)}")
            return False
    
    @staticmethod
    def read_csv(file_path: str) -> List[Dict]:
        """Read CSV file and return list of dictionaries"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                return list(reader)
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            return []
    
    @staticmethod
    def write_csv(file_path: str, data: List[Dict], fieldnames: List[str]) -> bool:
        """Write data to CSV file"""
        try:
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(data)
            return True
        except Exception as e:
            logger.error(f"Failed to write CSV to {file_path}: {str(e)}")
            return False
    
    @staticmethod
    def append_csv(file_path: str, data: Dict, fieldnames: List[str]) -> bool:
        """Append data to CSV file"""
        try:
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            file_exists = Path(file_path).exists()
            
            with open(file_path, 'a', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(data)
            return True
        except Exception as e:
            logger.error(f"Failed to append CSV to {file_path}: {str(e)}")
            return False
    
    @staticmethod
    def read_text(file_path: str) -> str:
        """Read text file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            return ""


class Validator:
    """Input validation utilities"""
    
    @staticmethod
    def validate_ticket_id(ticket_id: str) -> bool:
        """Validate ticket ID format (e.g., TKT-001)"""
        pattern = r'^TKT-\d{3,6}$'
        return bool(re.match(pattern, ticket_id))
    
    @staticmethod
    def validate_priority(priority: str) -> bool:
        """Validate priority level"""
        return priority in ['P1', 'P2', 'P3', 'P4']
    
    @staticmethod
    def validate_status(status: str) -> bool:
        """Validate ticket status"""
        return status in ['Open', 'In Progress', 'Pending', 'Resolved', 'Closed']
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def validate_phone(phone: str) -> bool:
        """Validate phone number format"""
        pattern = r'^\d{10,15}$'
        return bool(re.match(pattern, phone))
    
    @staticmethod
    def validate_non_empty(value: str, field_name: str) -> bool:
        """Validate non-empty string"""
        if not value or not value.strip():
            raise ValueError(f"{field_name} cannot be empty")
        return True


class DataProcessor:
    """Data processing utilities"""
    
    @staticmethod
    def sort_tickets(tickets: List[Dict], sort_by: str = 'created_date', 
                     reverse: bool = True) -> List[Dict]:
        """Sort tickets by specified field"""
        valid_sort_fields = ['ticket_id', 'created_date', 'priority', 'status', 'employee_name']
        
        if sort_by not in valid_sort_fields:
            sort_by = 'created_date'
        
        # Convert priority to numeric for sorting
        priority_order = {'P1': 1, 'P2': 2, 'P3': 3, 'P4': 4}
        
        if sort_by == 'priority':
            return sorted(tickets, 
                         key=lambda x: priority_order.get(x.get('priority', 'P4'), 4),
                         reverse=reverse)
        
        return sorted(tickets, key=lambda x: x.get(sort_by, ''), reverse=reverse)
    
    @staticmethod
    def filter_tickets(tickets: List[Dict], **filters) -> List[Dict]:
        """Filter tickets by multiple criteria"""
        result = tickets
        
        for key, value in filters.items():
            if value:
                result = [t for t in result if t.get(key) == value]
        
        return result
    
    @staticmethod
    def search_tickets(tickets: List[Dict], query: str) -> List[Dict]:
        """Search tickets by multiple fields"""
        query = query.lower()
        results = []
        
        for ticket in tickets:
            search_fields = [
                ticket.get('ticket_id', ''),
                ticket.get('employee_name', ''),
                ticket.get('department', ''),
                ticket.get('issue_description', ''),
                ticket.get('category', '')
            ]
            
            if any(query in str(field).lower() for field in search_fields):
                results.append(ticket)
        
        return results
    
    @staticmethod
    def calculate_sla_hours(priority: str) -> int:
        """Get SLA hours for priority level"""
        sla_map = {
            'P1': 1,   # 1 hour
            'P2': 4,   # 4 hours
            'P3': 8,   # 8 hours
            'P4': 24   # 24 hours
        }
        return sla_map.get(priority, 24)
    
    @staticmethod
    def get_priority_from_issue(issue_type: str) -> str:
        """Determine priority based on issue type"""
        issue_priority_map = {
            'server down': 'P1',
            'internet down': 'P2',
            'network down': 'P2',
            'laptop slow': 'P3',
            'printer failure': 'P3',
            'printer not working': 'P3',
            'application crash': 'P3',
            'app crash': 'P3',
            'disk full': 'P3',
            'high cpu': 'P3',
            'password reset': 'P4',
            'software install': 'P4',
            'email issue': 'P4',
            'wifi issue': 'P3'
        }
        
        issue_lower = issue_type.lower()
        return issue_priority_map.get(issue_lower, 'P4')


class DateTimeHelper:
    """Date and time utilities"""
    
    @staticmethod
    def get_current_datetime() -> str:
        """Get current datetime in ISO format"""
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    @staticmethod
    def get_current_date() -> str:
        """Get current date"""
        return datetime.now().strftime('%Y-%m-%d')
    
    @staticmethod
    def parse_datetime(date_str: str) -> datetime:
        """Parse datetime string"""
        try:
            return datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            try:
                return datetime.strptime(date_str, '%Y-%m-%d')
            except ValueError:
                return datetime.now()
    
    @staticmethod
    def calculate_hours_elapsed(start_date: str) -> float:
        """Calculate hours elapsed since start date"""
        start = DateTimeHelper.parse_datetime(start_date)
        elapsed = datetime.now() - start
        return elapsed.total_seconds() / 3600
    
    @staticmethod
    def format_datetime(dt: datetime) -> str:
        """Format datetime for display"""
        return dt.strftime('%Y-%m-%d %H:%M:%S')


class IDGenerator:
    """Generate unique IDs for tickets and records"""
    
    _ticket_counter = 0
    _incident_counter = 0
    _problem_counter = 0
    
    @classmethod
    def generate_ticket_id(cls) -> str:
        """Generate unique ticket ID"""
        cls._ticket_counter += 1
        return f"TKT-{cls._ticket_counter:06d}"
    
    @classmethod
    def generate_incident_id(cls) -> str:
        """Generate unique incident ID"""
        cls._incident_counter += 1
        return f"INC-{cls._incident_counter:06d}"
    
    @classmethod
    def generate_problem_id(cls) -> str:
        """Generate unique problem ID"""
        cls._problem_counter += 1
        return f"PRB-{cls._problem_counter:06d}"
    
    @classmethod
    def set_counters(cls, ticket_count: int = 0, incident_count: int = 0, 
                     problem_count: int = 0):
        """Set counters from existing data"""
        cls._ticket_counter = ticket_count
        cls._incident_counter = incident_count
        cls._problem_counter = problem_count


# Decorator for timing function execution
def timer_decorator(func):
    """Decorator to measure function execution time"""
    import time
    
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        logger.info(f"{func.__name__} executed in {end - start:.4f} seconds")
        return result
    return wrapper


# Decorator for retry logic
def retry_on_error(max_retries: int = 3):
    """Decorator to retry function on error"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    logger.warning(f"Retry {attempt + 1}/{max_retries} for {func.__name__}: {str(e)}")
            return None
        return wrapper
    return decorator


# List comprehension examples
def get_open_tickets(tickets: List[Dict]) -> List[Dict]:
    """Get all open tickets using list comprehension"""
    return [t for t in tickets if t.get('status') in ['Open', 'In Progress', 'Pending']]

def get_high_priority_tickets(tickets: List[Dict]) -> List[Dict]:
    """Get P1 and P2 tickets"""
    return [t for t in tickets if t.get('priority') in ['P1', 'P2']]

def get_tickets_by_department(tickets: List[Dict], department: str) -> List[Dict]:
    """Filter tickets by department"""
    return [t for t in tickets if t.get('department', '').lower() == department.lower()]


# Generator example
def ticket_generator(tickets: List[Dict]):
    """Generator to iterate through tickets one at a time"""
    for ticket in tickets:
        yield ticket


# Iterator example
class TicketIterator:
    """Iterator for tickets"""
    
    def __init__(self, tickets: List[Dict]):
        self._tickets = tickets
        self._index = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self._index >= len(self._tickets):
            raise StopIteration
        ticket = self._tickets[self._index]
        self._index += 1
        return ticket