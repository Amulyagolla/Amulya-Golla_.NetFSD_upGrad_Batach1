# filepath: main.py
"""
IT Service Desk - Main Entry Point
A Python-based automation system for IT helpdesk support
"""

import os
import sys
from datetime import datetime

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tickets import TicketManager, Ticket, IncidentTicket, ServiceRequest
from monitor import Monitor, AutoTicketCreator, MonitoringService
from itil import ITILService, SLATracker, IncidentManager, ServiceRequestManager, ProblemManager
from reports import ReportGenerator, generate_quick_report
from logger import logger, INFO, WARNING, ERROR
from utils import FileHandler, DateTimeHelper


class ITServiceDesk:
    """Main IT Service Desk application"""
    
    def __init__(self):
        """Initialize the IT Service Desk"""
        print("=" * 60)
        print("       WELCOME TO IT SERVICE DESK SYSTEM")
        print("=" * 60)
        print()
        
        # Initialize all managers
        self._ticket_manager = TicketManager()
        self._monitoring_service = MonitoringService()
        self._itil_service = ITILService(self._ticket_manager)
        self._report_generator = ReportGenerator(self._ticket_manager)
        
        # Enable auto ticket creation for monitoring alerts
        self._monitoring_service.enable_auto_ticket(self._ticket_manager)
        
        logger.info("IT Service Desk initialized")
        
        # Create sample data if no tickets exist
        if len(self._ticket_manager.get_all_tickets()) == 0:
            self._create_sample_data()
    
    def _create_sample_data(self):
        """Create sample tickets for demonstration"""
        print("Creating sample data...")
        
        # Sample tickets
        sample_tickets = [
            ("John Smith", "Engineering", "Laptop running very slow", "Laptop Slow"),
            ("Jane Doe", "Sales", "Cannot connect to internet", "Internet Down"),
            ("Mike Johnson", "HR", "Password not working, need reset", "Password Reset"),
            ("Sarah Williams", "Marketing", "Printer not printing documents", "Printer Failure"),
            ("Tom Brown", "Engineering", "Server down, cannot access files", "Server Down"),
            ("Emily Davis", "Finance", "Application crashes when opening", "Application Crash"),
            ("Chris Wilson", "IT", "Disk space running low", "Disk Full"),
            ("Amanda Taylor", "Sales", "High CPU usage on workstation", "High CPU"),
        ]
        
        for employee, dept, issue, category in sample_tickets:
            self._ticket_manager.create_ticket(
                employee_name=employee,
                department=dept,
                issue_description=issue,
                category=category
            )
        
        # Sample incidents
        self._itil_service.incident_manager.create_incident(
            employee_name="System Admin",
            department="IT",
            issue_description="Network switch failure affecting floor 2",
            incident_type="Network Down",
            impact_level="High",
            urgency="Critical",
            impacted_users=15
        )
        
        # Sample service requests
        self._itil_service.service_request_manager.create_request(
            employee_name="New Employee",
            department="Engineering",
            issue_description="Need development tools installed",
            request_type="Software Install",
            justification="Starting new project"
        )
        
        print(f"Created {len(sample_tickets) + 2} sample tickets")
    
    def display_menu(self):
        """Display main menu"""
        print("\n" + "=" * 60)
        print("                    MAIN MENU")
        print("=" * 60)
        print("1.  Ticket Management")
        print("2.  Incident Management")
        print("3.  Service Request Management")
        print("4.  Problem Management")
        print("5.  SLA Tracking")
        print("6.  System Monitoring")
        print("7.  Reports")
        print("8.  ITIL Summary")
        print("9.  Backup Data")
        print("0.  Exit")
        print("=" * 60)
    
    def ticket_management_menu(self):
        """Ticket Management submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       TICKET MANAGEMENT")
            print("-" * 40)
            print("1.  Create New Ticket")
            print("2.  View All Tickets")
            print("3.  Search Ticket by ID")
            print("4.  Search Tickets (General)")
            print("5.  Update Ticket Status")
            print("6.  Close Ticket")
            print("7.  Delete Ticket")
            print("8.  View Open Tickets")
            print("9.  View High Priority Tickets")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._create_ticket()
            elif choice == '2':
                self._view_all_tickets()
            elif choice == '3':
                self._search_ticket_by_id()
            elif choice == '4':
                self._search_tickets()
            elif choice == '5':
                self._update_ticket_status()
            elif choice == '6':
                self._close_ticket()
            elif choice == '7':
                self._delete_ticket()
            elif choice == '8':
                self._view_open_tickets()
            elif choice == '9':
                self._view_high_priority_tickets()
            elif choice == '0':
                break
            else:
                print("Invalid choice. Please try again.")
    
    def _create_ticket(self):
        """Create a new ticket"""
        print("\n--- Create New Ticket ---")
        
        try:
            employee_name = input("Employee Name: ").strip()
            department = input("Department: ").strip()
            issue_description = input("Issue Description: ").strip()
            category = input("Category: ").strip()
            
            if not employee_name or not department or not issue_description:
                print("Error: Required fields cannot be empty")
                return
            
            ticket = self._ticket_manager.create_ticket(
                employee_name=employee_name,
                department=department,
                issue_description=issue_description,
                category=category
            )
            
            print(f"\n✓ Ticket created successfully!")
            print(f"  Ticket ID: {ticket.ticket_id}")
            print(f"  Priority: {ticket.priority}")
            print(f"  Status: {ticket.status}")
            
        except Exception as e:
            print(f"Error creating ticket: {str(e)}")
    
    def _view_all_tickets(self):
        """View all tickets"""
        tickets = self._ticket_manager.get_all_tickets()
        
        if not tickets:
            print("\nNo tickets found.")
            return
        
        print(f"\n--- All Tickets ({len(tickets)}) ---")
        print("-" * 100)
        print(f"{'ID':<12} {'Employee':<15} {'Department':<12} {'Category':<20} {'Priority':<8} {'Status':<12}")
        print("-" * 100)
        
        for ticket in tickets:
            print(f"{ticket.ticket_id:<12} {ticket.employee_name[:15]:<15} {ticket.department[:12]:<12} "
                  f"{ticket.category[:20]:<20} {ticket.priority:<8} {ticket.status:<12}")
        
        print("-" * 100)
    
    def _search_ticket_by_id(self):
        """Search ticket by ID"""
        ticket_id = input("\nEnter Ticket ID (e.g., TKT-000001): ").strip()
        
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if ticket:
            print(f"\n--- Ticket Details ---")
            print(f"Ticket ID:      {ticket.ticket_id}")
            print(f"Employee:       {ticket.employee_name}")
            print(f"Department:     {ticket.department}")
            print(f"Issue:          {ticket.issue_description}")
            print(f"Category:       {ticket.category}")
            print(f"Priority:       {ticket.priority} ({ticket.get_priority_display(ticket.priority)})")
            print(f"Status:         {ticket.status}")
            print(f"Created:        {ticket.created_date}")
            print(f"Updated:        {ticket.updated_date}")
            if ticket.resolved_date:
                print(f"Resolved:       {ticket.resolved_date}")
            if ticket.closed_date:
                print(f"Closed:         {ticket.closed_date}")
            if ticket.resolution:
                print(f"Resolution:     {ticket.resolution}")
        else:
            print(f"Ticket not found: {ticket_id}")
    
    def _search_tickets(self):
        """Search tickets by query"""
        query = input("\nEnter search query: ").strip()
        
        results = self._ticket_manager.search_tickets(query)
        
        if results:
            print(f"\n--- Search Results ({len(results)}) ---")
            for ticket in results:
                print(f"  {ticket.ticket_id}: {ticket.employee_name} - {ticket.category} ({ticket.status})")
        else:
            print("No tickets found matching your query.")
    
    def _update_ticket_status(self):
        """Update ticket status"""
        ticket_id = input("\nEnter Ticket ID: ").strip()
        
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if not ticket:
            print(f"Ticket not found: {ticket_id}")
            return
        
        print(f"Current Status: {ticket.status}")
        print("Available statuses: Open, In Progress, Pending, Resolved, Closed")
        
        new_status = input("Enter new status: ").strip()
        
        if new_status in ['Open', 'In Progress', 'Pending', 'Resolved', 'Closed']:
            resolution = None
            if new_status in ['Resolved', 'Closed']:
                resolution = input("Enter resolution: ").strip()
            
            success = self._ticket_manager.update_ticket_status(ticket_id, new_status, resolution)
            
            if success:
                print(f"✓ Status updated to {new_status}")
            else:
                print("Failed to update status")
        else:
            print("Invalid status")
    
    def _close_ticket(self):
        """Close a ticket"""
        ticket_id = input("\nEnter Ticket ID to close: ").strip()
        resolution = input("Enter resolution: ").strip()
        
        success = self._ticket_manager.close_ticket(ticket_id, resolution)
        
        if success:
            print(f"✓ Ticket {ticket_id} closed successfully")
        else:
            print("Failed to close ticket")
    
    def _delete_ticket(self):
        """Delete a ticket"""
        ticket_id = input("\nEnter Ticket ID to delete: ").strip()
        
        confirm = input(f"Confirm delete ticket {ticket_id}? (y/n): ").strip().lower()
        
        if confirm == 'y':
            success = self._ticket_manager.delete_ticket(ticket_id)
            if success:
                print(f"✓ Ticket {ticket_id} deleted")
            else:
                print("Failed to delete ticket")
        else:
            print("Delete cancelled")
    
    def _view_open_tickets(self):
        """View open tickets"""
        tickets = self._ticket_manager.get_open_tickets()
        
        if not tickets:
            print("\nNo open tickets.")
            return
        
        print(f"\n--- Open Tickets ({len(tickets)}) ---")
        for ticket in tickets:
            print(f"  {ticket.ticket_id}: {ticket.category} - {ticket.priority} - {ticket.status}")
    
    def _view_high_priority_tickets(self):
        """View high priority tickets"""
        tickets = self._ticket_manager.get_high_priority_tickets()
        
        if not tickets:
            print("\nNo high priority tickets.")
            return
        
        print(f"\n--- High Priority Tickets ({len(tickets)}) ---")
        for ticket in tickets:
            print(f"  {ticket.ticket_id}: {ticket.category} - {ticket.priority} - {ticket.status}")
    
    def incident_management_menu(self):
        """Incident Management submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       INCIDENT MANAGEMENT")
            print("-" * 40)
            print("1.  Create Incident")
            print("2.  View Active Incidents")
            print("3.  View Major Incidents")
            print("4.  Resolve Incident")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._create_incident()
            elif choice == '2':
                self._view_active_incidents()
            elif choice == '3':
                self._view_major_incidents()
            elif choice == '4':
                self._resolve_incident()
            elif choice == '0':
                break
            else:
                print("Invalid choice")
    
    def _create_incident(self):
        """Create an incident"""
        print("\n--- Create Incident ---")
        
        employee_name = input("Employee Name: ").strip()
        department = input("Department: ").strip()
        issue_description = input("Issue Description: ").strip()
        incident_type = input("Incident Type: ").strip()
        impact = input("Impact Level (Low/Medium/High/Critical): ").strip()
        urgency = input("Urgency (Low/Medium/High/Critical): ").strip()
        
        try:
            incident = self._itil_service.incident_manager.create_incident(
                employee_name=employee_name,
                department=department,
                issue_description=issue_description,
                incident_type=incident_type,
                impact_level=impact,
                urgency=urgency
            )
            
            print(f"\n✓ Incident created: {incident.ticket_id}")
            print(f"  Priority: {incident.priority}")
            
        except Exception as e:
            print(f"Error: {str(e)}")
    
    def _view_active_incidents(self):
        """View active incidents"""
        incidents = self._itil_service.incident_manager.get_active_incidents()
        
        if not incidents:
            print("\nNo active incidents.")
            return
        
        print(f"\n--- Active Incidents ({len(incidents)}) ---")
        for inc in incidents:
            print(f"  {inc.ticket_id}: {inc.incident_type} - {inc.priority} - {inc.status}")
    
    def _view_major_incidents(self):
        """View major incidents"""
        incidents = self._itil_service.incident_manager.get_major_incidents()
        
        if not incidents:
            print("\nNo major incidents.")
            return
        
        print(f"\n--- Major Incidents ({len(incidents)}) ---")
        for inc in incidents:
            print(f"  {inc.ticket_id}: {inc.incident_type} - {inc.priority} - Service Affecting: {inc.service_affecting}")
    
    def _resolve_incident(self):
        """Resolve an incident"""
        ticket_id = input("\nEnter Incident ID: ").strip()
        resolution = input("Resolution: ").strip()
        root_cause = input("Root Cause (optional): ").strip()
        
        success = self._itil_service.incident_manager.resolve_incident(
            ticket_id, resolution, root_cause
        )
        
        if success:
            print(f"✓ Incident resolved: {ticket_id}")
        else:
            print("Failed to resolve incident")
    
    def service_request_menu(self):
        """Service Request submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       SERVICE REQUEST MANAGEMENT")
            print("-" * 40)
            print("1.  Create Service Request")
            print("2.  View Pending Requests")
            print("3.  Approve Request")
            print("4.  Reject Request")
            print("5.  Fulfill Request")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._create_service_request()
            elif choice == '2':
                self._view_pending_requests()
            elif choice == '3':
                self._approve_request()
            elif choice == '4':
                self._reject_request()
            elif choice == '5':
                self._fulfill_request()
            elif choice == '0':
                break
            else:
                print("Invalid choice")
    
    def _create_service_request(self):
        """Create a service request"""
        print("\n--- Create Service Request ---")
        
        employee_name = input("Employee Name: ").strip()
        department = input("Department: ").strip()
        issue_description = input("Description: ").strip()
        request_type = input("Request Type: ").strip()
        justification = input("Justification: ").strip()
        
        try:
            request = self._itil_service.service_request_manager.create_request(
                employee_name=employee_name,
                department=department,
                issue_description=issue_description,
                request_type=request_type,
                justification=justification
            )
            
            print(f"\n✓ Service request created: {request.ticket_id}")
            print(f"  Approval Status: {request.approval_status}")
            
        except Exception as e:
            print(f"Error: {str(e)}")
    
    def _view_pending_requests(self):
        """View pending requests"""
        requests = self._itil_service.service_request_manager.get_pending_requests()
        
        if not requests:
            print("\nNo pending requests.")
            return
        
        print(f"\n--- Pending Requests ({len(requests)}) ---")
        for req in requests:
            print(f"  {req.ticket_id}: {req.request_type} - {req.employee_name}")
    
    def _approve_request(self):
        """Approve a request"""
        ticket_id = input("\nEnter Request ID: ").strip()
        approver = input("Approver Name: ").strip()
        
        success = self._itil_service.service_request_manager.approve_request(ticket_id, approver)
        
        if success:
            print(f"✓ Request approved: {ticket_id}")
        else:
            print("Failed to approve request")
    
    def _reject_request(self):
        """Reject a request"""
        ticket_id = input("\nEnter Request ID: ").strip()
        approver = input("Rejecter Name: ").strip()
        reason = input("Reason: ").strip()
        
        success = self._itil_service.service_request_manager.reject_request(ticket_id, approver, reason)
        
        if success:
            print(f"✓ Request rejected: {ticket_id}")
        else:
            print("Failed to reject request")
    
    def _fulfill_request(self):
        """Fulfill a request"""
        ticket_id = input("\nEnter Request ID: ").strip()
        
        success = self._itil_service.service_request_manager.fulfill_request(ticket_id)
        
        if success:
            print(f"✓ Request fulfilled: {ticket_id}")
        else:
            print("Failed to fulfill request")
    
    def problem_management_menu(self):
        """Problem Management submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       PROBLEM MANAGEMENT")
            print("-" * 40)
            print("1.  Analyze Repeated Issues")
            print("2.  Create Problem Record")
            print("3.  View All Problems")
            print("4.  Update Problem Status")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._analyze_repeated_issues()
            elif choice == '2':
                self._create_problem_record()
            elif choice == '3':
                self._view_all_problems()
            elif choice == '4':
                self._update_problem_status()
            elif choice == '0':
                break
            else:
                print("Invalid choice")
    
    def _analyze_repeated_issues(self):
        """Analyze repeated issues"""
        repeated = self._itil_service.problem_manager.analyze_repeated_issues()
        
        if not repeated:
            print("\nNo repeated issues found (threshold: 5 occurrences)")
            return
        
        print(f"\n--- Repeated Issues ---")
        for item in repeated:
            print(f"  {item['category']}: {item['count']} occurrences")
        
        # Auto-create problem record
        create = input("\nCreate problem record for most common issue? (y/n): ").strip().lower()
        if create == 'y':
            self._itil_service.problem_manager.create_problem_from_repeated_issues()
            print("Problem record created")
    
    def _create_problem_record(self):
        """Create problem record"""
        category = input("\nEnter category to create problem for: ").strip()
        
        problem = self._itil_service.problem_manager.create_problem_from_repeated_issues(category)
        
        if problem:
            print(f"✓ Problem record created: {problem.problem_id}")
        else:
            print("Failed to create problem record (need 5+ occurrences)")
    
    def _view_all_problems(self):
        """View all problems"""
        problems = self._itil_service.problem_manager.get_all_problems()
        
        if not problems:
            print("\nNo problem records found.")
            return
        
        print(f"\n--- Problem Records ({len(problems)}) ---")
        for problem in problems:
            print(f"  {problem.problem_id}: {problem.title} - {problem.status}")
            print(f"    Related Tickets: {len(problem.related_tickets)}")
    
    def _update_problem_status(self):
        """Update problem status"""
        problem_id = input("\nEnter Problem ID: ").strip()
        status = input("New Status: ").strip()
        resolution = input("Resolution (optional): ").strip()
        root_cause = input("Root Cause (optional): ").strip()
        
        success = self._itil_service.problem_manager.update_problem_status(
            problem_id, status, resolution, root_cause
        )
        
        if success:
            print(f"✓ Problem updated: {problem_id}")
        else:
            print("Failed to update problem")
    
    def sla_tracking_menu(self):
        """SLA Tracking submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       SLA TRACKING")
            print("-" * 40)
            print("1.  Check SLA Status")
            print("2.  View Breached SLAs")
            print("3.  View Pending Tickets with SLA")
            print("4.  Get SLA Compliance Report")
            print("5.  Escalate Breached Tickets")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._check_sla_status()
            elif choice == '2':
                self._view_breached_slas()
            elif choice == '3':
                self._view_pending_with_sla()
            elif choice == '4':
                self._get_sla_compliance()
            elif choice == '5':
                self._escalate_breached()
            elif choice == '0':
                break
            else:
                print("Invalid choice")
    
    def _check_sla_status(self):
        """Check SLA status for a ticket"""
        ticket_id = input("\nEnter Ticket ID: ").strip()
        
        ticket = self._ticket_manager.get_ticket_by_id(ticket_id)
        
        if not ticket:
            print("Ticket not found")
            return
        
        sla_status = self._itil_service.sla_tracker.check_sla(ticket)
        
        print(f"\n--- SLA Status for {ticket_id} ---")
        print(f"Priority: {sla_status['priority']}")
        print(f"SLA Hours: {sla_status['sla_hours']}")
        print(f"Elapsed Hours: {sla_status['elapsed_hours']}")
        print(f"Remaining Hours: {sla_status['remaining_hours']}")
        print(f"Breached: {'YES' if sla_status['breached'] else 'NO'}")
    
    def _view_breached_slas(self):
        """View breached SLAs"""
        breached = self._itil_service.sla_tracker.get_all_breached_tickets()
        
        if not breached:
            print("\nNo SLA breaches found.")
            return
        
        print(f"\n--- Breached SLAs ({len(breached)}) ---")
        for ticket in breached:
            print(f"  {ticket.ticket_id}: {ticket.category} - {ticket.priority}")
    
    def _view_pending_with_sla(self):
        """View pending tickets with SLA info"""
        pending = self._itil_service.sla_tracker.get_pending_tickets()
        
        if not pending:
            print("\nNo pending tickets.")
            return
        
        print(f"\n--- Pending Tickets with SLA ({len(pending)}) ---")
        for item in pending[:10]:
            ticket = item['ticket']
            sla = item['sla']
            print(f"  {ticket.ticket_id}: {sla['remaining_hours']}h remaining - {ticket.priority}")
    
    def _get_sla_compliance(self):
        """Get SLA compliance report"""
        compliance = self._itil_service.sla_tracker.get_sla_compliance()
        
        print(f"\n--- SLA Compliance ---")
        print(f"Total Tickets: {compliance['total_tickets']}")
        print(f"Breached: {compliance['breached']}")
        print(f"Compliant: {compliance['compliant']}")
        print(f"Compliance Rate: {compliance['compliance_rate']}%")
    
    def _escalate_breached(self):
        """Escalate breached tickets"""
        breached = self._itil_service.sla_tracker.get_all_breached_tickets()
        
        if not breached:
            print("\nNo breached tickets to escalate.")
            return
        
        count = 0
        for ticket in breached:
            if self._itil_service.sla_tracker.escalate_ticket(ticket):
                count += 1
        
        self._ticket_manager._save_tickets()
        print(f"✓ Escalated {count} tickets")
    
    def system_monitoring_menu(self):
        """System Monitoring submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       SYSTEM MONITORING")
            print("-" * 40)
            print("1.  Check System Status")
            print("2.  Get System Health")
            print("3.  Get System Metrics")
            print("4.  Check and Auto-Create Ticket")
            print("5.  View Alert History")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._check_system_status()
            elif choice == '2':
                self._get_system_health()
            elif choice == '3':
                self._get_system_metrics()
            elif choice == '4':
                self._check_and_create_ticket()
            elif choice == '5':
                self._view_alert_history()
            elif choice == '0':
                break
            else:
                print("Invalid choice")
    
    def _check_system_status(self):
        """Check system status"""
        status = self._monitoring_service.get_system_status()
        
        print(f"\n--- System Status ---")
        print(f"Timestamp: {status['timestamp']}")
        print(f"CPU: {status['cpu']['value']}% (Threshold: {status['cpu']['threshold']}%)")
        print(f"Memory: {status['memory']['value']}% (Threshold: {status['memory']['threshold']}%)")
        print(f"Disk Free: {status['disk']['value']}% (Threshold: {status['disk']['threshold']}%)")
        
        if status['alerts']:
            print("\n⚠ Alerts:")
            for alert in status['alerts']:
                print(f"  - {alert}")
        else:
            print("\n✓ All systems normal")
    
    def _get_system_health(self):
        """Get system health"""
        health = self._monitoring_service.get_system_health()
        report = self._monitoring_service.generate_health_report()
        
        print(f"\n--- System Health ---")
        print(f"Health Status: {health}")
        print(report)
    
    def _get_system_metrics(self):
        """Get system metrics"""
        from monitor import Monitor
        
        metrics = Monitor.get_system_info()
        
        print(f"\n--- System Metrics ---")
        print(f"CPU: {metrics['cpu']['usage_percent']}%")
        print(f"CPU Count: {metrics['cpu']['count']}")
        print(f"Memory: {metrics['memory']['used_gb']}GB / {metrics['memory']['total_gb']}GB")
        print(f"Disk: {metrics['disk']['used']/(1024**3):.2f}GB / {metrics['disk']['total']/(1024**3):.2f}GB")
        print(f"Network: {metrics['network']['mb_sent']}MB sent, {metrics['network']['mb_recv']}MB received")
    
    def _check_and_create_ticket(self):
        """Check and auto-create ticket"""
        ticket_id = self._monitoring_service.auto_creator.check_and_create_ticket()
        
        if ticket_id:
            print(f"✓ Auto-created ticket: {ticket_id}")
        else:
            print("No alerts detected, no ticket created")
    
    def _view_alert_history(self):
        """View alert history"""
        history = self._monitoring_service.monitor.alert_history
        
        if not history:
            print("\nNo alerts recorded.")
            return
        
        print(f"\n--- Alert History ({len(history)}) ---")
        for alert in history[-10:]:
            print(f"  {alert['timestamp']}")
            if alert.get('alerts'):
                for a in alert['alerts']:
                    print(f"    - {a}")
    
    def reports_menu(self):
        """Reports submenu"""
        while True:
            print("\n" + "-" * 40)
            print("       REPORTS")
            print("-" * 40)
            print("1.  Daily Report")
            print("2.  Monthly Report")
            print("3.  Summary Report")
            print("4.  Quick Summary")
            print("5.  Ticket Statistics")
            print("0.  Back to Main Menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == '1':
                self._daily_report()
            elif choice == '2':
                self._monthly_report()
            elif choice == '3':
                self._summary_report()
            elif choice == '4':
                self._quick_summary()
            elif choice == '5':
                self._ticket_statistics()
            elif choice == '0':
                break
            else:
                print("Invalid choice")
    
    def _daily_report(self):
        """Generate daily report"""
        date = input("Enter date (YYYY-MM-DD) or press Enter for today: ").strip()
        
        if not date:
            date = None
        
        report = self._report_generator.generate_daily_report(date)
        
        print(self._report_generator.format_daily_report(report))
        print(self._report_generator.format_daily_report_continued(report))
    
    def _monthly_report(self):
        """Generate monthly report"""
        year = input("Enter year (YYYY) or press Enter for current: ").strip()
        month = input("Enter month (1-12) or press Enter for current: ").strip()
        
        year = int(year) if year else None
        month = int(month) if month else None
        
        report = self._report_generator.generate_monthly_report(year, month)
        
        print(self._report_generator.format_monthly_report(report))
        print(self._report_generator.format_monthly_report_continued(report))
    
    def _summary_report(self):
        """Generate summary report"""
        report = self._report_generator.generate_summary_report()
        
        print(f"\n--- Summary Report ---")
        print(f"Total Tickets: {report['total_tickets']}")
        print(f"Open: {report['open_tickets']}")
        print(f"Closed: {report['closed_tickets']}")
        print(f"High Priority Open: {report['high_priority_open']}")
        print(f"SLA Breaches: {report['sla_breaches']}")
    
    def _quick_summary(self):
        """Generate quick summary"""
        print(generate_quick_report(self._ticket_manager))
    
    def _ticket_statistics(self):
        """Get ticket statistics"""
        stats = self._ticket_manager.get_ticket_count()
        
        print(f"\n--- Ticket Statistics ---")
        print(f"Total: {stats['total']}")
        print(f"Open: {stats['open']}")
        print(f"In Progress: {stats['in_progress']}")
        print(f"Pending: {stats['pending']}")
        print(f"Resolved: {stats['resolved']}")
        print(f"Closed: {stats['closed']}")
        print(f"\nBy Priority:")
        print(f"P1: {stats['p1']}")
        print(f"P2: {stats['p2']}")
        print(f"P3: {stats['p3']}")
        print(f"P4: {stats['p4']}")
    
    def itil_summary(self):
        """Show ITIL summary"""
        print(self._itil_service.get_itil_summary())
    
    def backup_data(self):
        """Backup data to CSV"""
        success = self._ticket_manager.create_backup()
        
        if success:
            print("✓ Backup created successfully: data/backup.csv")
        else:
            print("✗ Backup failed")
    
    def run(self):
        """Run the main application loop"""
        while True:
            self.display_menu()
            choice = input("\nEnter your choice: ").strip()
            
            if choice == '1':
                self.ticket_management_menu()
            elif choice == '2':
                self.incident_management_menu()
            elif choice == '3':
                self.service_request_menu()
            elif choice == '4':
                self.problem_management_menu()
            elif choice == '5':
                self.sla_tracking_menu()
            elif choice == '6':
                self.system_monitoring_menu()
            elif choice == '7':
                self.reports_menu()
            elif choice == '8':
                self.itil_summary()
            elif choice == '9':
                self.backup_data()
            elif choice == '0':
                print("\nThank you for using IT Service Desk!")
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please try again.")


def main():
    """Main entry point"""
    try:
        app = ITServiceDesk()
        app.run()
    except KeyboardInterrupt:
        print("\n\nExiting...")
    except Exception as e:
        print(f"\nError: {str(e)}")
        logger.error(f"Application error: {str(e)}")


if __name__ == "__main__":
    main()