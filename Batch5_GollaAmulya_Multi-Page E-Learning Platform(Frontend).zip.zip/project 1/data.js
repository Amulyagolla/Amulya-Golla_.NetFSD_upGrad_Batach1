const courses = [
  {
    id: 'c1',
    title: 'Introduction to Web Development',
    description: 'HTML5, CSS3, and JavaScript fundamentals for modern web apps.',
    lessons: ['HTML semantics', 'CSS layouts', 'Responsive design', 'JavaScript basics'],
    hours: 6,
  },
  {
    id: 'c2',
    title: 'Advanced JavaScript',
    description: 'Closures, asynchronous programming, and clean architecture.',
    lessons: ['Scope and closures', 'Promises and async/await', 'Modules', 'Design patterns'],
    hours: 8,
  },
  {
    id: 'c3',
    title: 'UI/UX Design Principles',
    description: 'Accessible and responsive designs using Bootstrap and semantic HTML.',
    lessons: ['Wireframing', 'Color theory', 'Accessibility', 'Mobile-first design'],
    hours: 5,
  },
  {
    id: 'c4',
    title: 'Web Performance & SEO',
    description: 'Optimize loading speed and discoverability for client-side apps.',
    lessons: ['Lazy loading', 'Minification', 'SEO metadata', 'Performance metrics'],
    hours: 4,
  },
];

const quizQuestions = [
  {
    id: 'q1',
    question: 'Which HTML element is used to define the main navigation of a page?',
    options: ['<main>', '<aside>', '<nav>', '<section>'],
    answer: '<nav>',
  },
  {
    id: 'q2',
    question: 'How do you declare a JavaScript function expression?',
    options: ['function myFn() {}', 'const myFn = function() {}', 'var myFn => {}', 'let function myFn() {}'],
    answer: 'const myFn = function() {}',
  },
  {
    id: 'q3',
    question: 'Which CSS property controls the space between flex items?',
    options: ['gap', 'margin', 'padding', 'justify-content'],
    answer: 'gap',
  },
  {
    id: 'q4',
    question: 'In localStorage, data is stored as:',
    options: ['Raw JSON objects', 'Strings', 'Binary buffers', 'Encrypted blobs'],
    answer: 'Strings',
  },
  {
    id: 'q5',
    question: 'Which statement is true for async/await in JavaScript?',
    options: ['await can be used outside async', 'async returns a Promise', 'async and await are keywords in CSS', 'await forces synchronous execution'],
    answer: 'async returns a Promise',
  },
];

function getStorageData(key, defaultValue) {
  const raw = localStorage.getItem(key);
  if (!raw) {
    return defaultValue;
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.warn('localStorage parse error for', key, error);
    return defaultValue;
  }
}

function setStorageData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function getCompletedCourses() {
  return getStorageData('completedCourses', []);
}

function setCompletedCourses(courseIds) {
  setStorageData('completedCourses', courseIds);
}

function addCompletedCourse(courseId) {
  const completed = new Set(getCompletedCourses());
  completed.add(courseId);
  setCompletedCourses(Array.from(completed));
}

function getQuizResults() {
  return getStorageData('quizResults', []);
}

function saveQuizResult(result) {
  const all = getQuizResults();
  all.push(result);
  setStorageData('quizResults', all);
}

function getProfile() {
  const profile = getStorageData('learnerProfile', null);
  if (profile) return profile;
  const defaultProfile = { name: 'Learner', email: 'learner@example.com', enrolledSince: new Date().toISOString() };
  setStorageData('learnerProfile', defaultProfile);
  return defaultProfile;
}

function setProfile(profile) {
  setStorageData('learnerProfile', profile);
}

function calculateScore(selectedAnswers, questions) {
  let score = 0;
  questions.forEach((q) => {
    if (selectedAnswers[q.id] === q.answer) {
      score += 1;
    }
  });
  return score;
}

function calculatePercentage(score, total) {
  if (total === 0) return 0;
  return Math.round((score / total) * 100);
}

function determineGrade(percentage) {
  if (percentage >= 90) return 'A';
  if (percentage >= 80) return 'B';
  if (percentage >= 70) return 'C';
  if (percentage >= 60) return 'D';
  return 'F';
}

function passFail(percentage) {
  return percentage >= 60;
}

function performanceMessage(percentage) {
  switch (true) {
    case percentage >= 90:
      return 'Outstanding work: Keep pushing your mastery!';
    case percentage >= 80:
      return 'Great job: You are on a strong path.';
    case percentage >= 70:
      return 'Good effort: Review key sections for improvement.';
    case percentage >= 60:
      return 'Satisfactory: A bit more practice will help.';
    default:
      return 'Needs improvement: Revisit lessons and retry the quiz.';
  }
}

async function simulateAsyncLoad(delay = 800) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(true), delay);
  });
}

async function loadQuiz() {
  await simulateAsyncLoad(1200);
  return quizQuestions;
}

function buildBreadcrumbs(path) {
  const breadcrumb = document.getElementById('breadcrumb');
  if (!breadcrumb) return;
  breadcrumb.innerHTML = '';
  const steps = path.split('/');
  let accumulated = '';
  steps.forEach((step, index) => {
    if (index === 0 && step === '') {
      accumulated = 'dashboard.html';
      const a = document.createElement('a');
      a.href = 'dashboard.html';
      a.textContent = 'Dashboard';
      breadcrumb.append(a);
      return;
    }
    if (!step) return;
    if (index > 0) {
      breadcrumb.append(' > ');
    }
    const a = document.createElement('a');
    a.href = accumulated ? accumulated : '#';
    a.textContent = step.replace('.html', '').replace('-', ' ');
    breadcrumb.append(a);
    if (step.endsWith('.html')) {
      accumulated = step;
    } else {
      accumulated += `${step}.html`;
    }
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    calculateScore,
    calculatePercentage,
    determineGrade,
    passFail,
    performanceMessage,
  };
}
