const { calculateScore, calculatePercentage, determineGrade, passFail } = require('./data');

describe('Quiz scoring utilities', () => {
  test('calculateScore returns correct number of correct answers', () => {
    const questionList = [
      { id: 'q1', answer: 'A' },
      { id: 'q2', answer: 'B' },
      { id: 'q3', answer: 'C' },
    ];
    const answers = { q1: 'A', q2: 'C', q3: 'C' };
    expect(calculateScore(answers, questionList)).toBe(2);
  });

  test('calculatePercentage returns rounded percentage', () => {
    expect(calculatePercentage(3, 5)).toBe(60);
    expect(calculatePercentage(1, 3)).toBe(33);
    expect(calculatePercentage(0, 10)).toBe(0);
  });

  test('passFail determines pass when percentage >= 60', () => {
    expect(passFail(85)).toBe(true);
    expect(passFail(60)).toBe(true);
    expect(passFail(59)).toBe(false);
  });

  test('determineGrade returns correct grade', () => {
    expect(determineGrade(95)).toBe('A');
    expect(determineGrade(85)).toBe('B');
    expect(determineGrade(75)).toBe('C');
    expect(determineGrade(65)).toBe('D');
    expect(determineGrade(50)).toBe('F');
  });
});